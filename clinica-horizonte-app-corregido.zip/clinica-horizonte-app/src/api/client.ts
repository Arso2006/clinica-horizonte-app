import {
  Patient,
  Professional,
  Appointment,
  Encounter,
  Invoice,
  AuditEvent,
  User,
  OperationalReport,
  BillingReport,
  PaginatedResponse,
} from '../types';
import {
  INITIAL_USERS,
  INITIAL_PROFESSIONALS,
  INITIAL_PATIENTS,
  INITIAL_APPOINTMENTS,
  INITIAL_ENCOUNTERS,
  INITIAL_INVOICES,
  INITIAL_AUDIT_EVENTS,
  MOCK_OPERATIONS_REPORT,
  MOCK_BILLING_REPORT
} from './mockData';

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';
const API_PREFIX = '/api/v1';

// In-memory / localStorage state for interactive fallback
const STORAGE_PREFIX = 'clinica_horizonte_';

function getStored<T>(key: string, defaultVal: T): T {
  try {
    const raw = localStorage.getItem(STORAGE_PREFIX + key);
    if (!raw) return defaultVal;
    const parsed = JSON.parse(raw);
    // Si el valor por defecto es una lista, el dato guardado también debe serlo
    if (Array.isArray(defaultVal) && !Array.isArray(parsed)) return defaultVal;
    return parsed;
  } catch {
    return defaultVal;
  }
}

function setStored<T>(key: string, val: T): void {
  try {
    localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(val));
  } catch (e) {
    console.error('Storage error', e);
  }
}

// Persistent reactive state
let patientsState: Patient[] = getStored('patients', INITIAL_PATIENTS);
let appointmentsState: Appointment[] = getStored('appointments', INITIAL_APPOINTMENTS);
let encountersState: Encounter[] = getStored('encounters', INITIAL_ENCOUNTERS);
let invoicesState: Invoice[] = getStored('invoices', INITIAL_INVOICES);
let auditEventsState: AuditEvent[] = getStored('audit', INITIAL_AUDIT_EVENTS);

class ApiClient {
  private accessToken: string | null = localStorage.getItem('token');
  private refreshToken: string | null = localStorage.getItem('refreshToken');
  private isOnlineBackend: boolean | null = null;

  setTokens(access: string | null, refresh: string | null) {
    this.accessToken = access;
    this.refreshToken = refresh;
    if (access) {
      localStorage.setItem('token', access);
    } else {
      localStorage.removeItem('token');
    }
    if (refresh) {
      localStorage.setItem('refreshToken', refresh);
    } else {
      localStorage.removeItem('refreshToken');
    }
  }

  getAccessToken() {
    return this.accessToken;
  }

  private async checkBackendHealth(): Promise<boolean> {
    if (this.isOnlineBackend !== null) return this.isOnlineBackend;
    try {
      const res = await fetch(`${BASE_URL}/health/live`, { method: 'GET', signal: AbortSignal.timeout(1200) });
      this.isOnlineBackend = res.ok;
    } catch {
      this.isOnlineBackend = false;
    }
    return this.isOnlineBackend;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const isOnline = await this.checkBackendHealth();
    if (!isOnline) {
      throw new Error('BACKEND_OFFLINE');
    }

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>),
    };

    if (this.accessToken) {
      headers['Authorization'] = `Bearer ${this.accessToken}`;
    }

    const res = await fetch(`${BASE_URL}${API_PREFIX}${endpoint}`, {
      ...options,
      headers,
    });

    if (res.status === 401 && this.refreshToken) {
      const refreshed = await this.refreshSession();
      if (refreshed) {
        headers['Authorization'] = `Bearer ${this.accessToken}`;
        const retryRes = await fetch(`${BASE_URL}${API_PREFIX}${endpoint}`, {
          ...options,
          headers,
        });
        if (!retryRes.ok) throw await retryRes.json();
        return retryRes.json();
      }
    }

    if (!res.ok) {
      const errorBody = await res.json().catch(() => ({ message: res.statusText }));
      throw errorBody;
    }

    if (res.status === 204) {
      return {} as T;
    }

    return res.json();
  }

  private async refreshSession(): Promise<boolean> {
    try {
      const res = await fetch(`${BASE_URL}${API_PREFIX}/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: this.refreshToken }),
      });
      if (res.ok) {
        const data = await res.json();
        this.setTokens(data.access_token, data.refresh_token);
        return true;
      }
    } catch {
      // Refresh failed
    }
    this.setTokens(null, null);
    return false;
  }

  // --- Auth ---
  async login(email: string, password: string):Promise<{ user: User; access_token: string; refresh_token: string }> {
    try {
      const data = await this.request<{ access_token: string; refresh_token: string; user?: User }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      });
      this.setTokens(data.access_token, data.refresh_token);
      const user = data.user || (await this.getMe());
      return { user, access_token: data.access_token, refresh_token: data.refresh_token };
    } catch (e) {
      // Fallback auth
      const found = INITIAL_USERS.find(u => u.email.toLowerCase() === email.toLowerCase());
      if (found) {
        const dummyToken = 'mock-jwt-' + found.id;
        this.setTokens(dummyToken, 'mock-refresh-' + found.id);
        this.recordAuditEvent('USER_LOGIN', 'auth', found.id, { email: found.email });
        return { user: found, access_token: dummyToken, refresh_token: 'mock-refresh-' + found.id };
      }
      throw new Error('Credenciales inválidas');
    }
  }

  async logout(): Promise<void> {
    try {
      await this.request('/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    } finally {
      this.setTokens(null, null);
    }
  }

  async getMe(): Promise<User> {
    try {
      return await this.request<User>('/auth/me');
    } catch {
      const rawUser = localStorage.getItem('currentUser');
      if (rawUser) return JSON.parse(rawUser);
      return INITIAL_USERS[0];
    }
  }

  // --- Patients ---
  async getPatients(query: string = '', page: number = 1, pageSize: number = 20): Promise<PaginatedResponse<Patient>> {
    try {
      const q = new URLSearchParams({ page: String(page), page_size: String(pageSize) });
      if (query) q.set('query', query);
      return await this.request<PaginatedResponse<Patient>>(`/patients?${q.toString()}`);
    } catch {
      let filtered = [...patientsState];
      if (query.trim()) {
        const s = query.toLowerCase();
        filtered = filtered.filter(p =>
          p.personal_identifier.toLowerCase().includes(s) ||
          p.first_names.toLowerCase().includes(s) ||
          p.last_names.toLowerCase().includes(s)
        );
      }
      const start = (page - 1) * pageSize;
      return {
        items: filtered.slice(start, start + pageSize),
        total: filtered.length,
        page,
        page_size: pageSize
      };
    }
  }

  async getPatient(id: string): Promise<Patient> {
    try {
      return await this.request<Patient>(`/patients/${id}`);
    } catch {
      const p = patientsState.find(item => item.id === id);
      if (!p) throw new Error('Paciente no encontrado');
      return p;
    }
  }

  async createPatient(data: Omit<Patient, 'id' | 'created_at' | 'updated_at'>): Promise<Patient> {
    try {
      return await this.request<Patient>('/patients', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    } catch {
      // Check duplicate identifier
      if (patientsState.some(p => p.personal_identifier === data.personal_identifier)) {
        throw new Error('Ya existe un paciente registrado con este RUT/Identificador');
      }
      const now = new Date().toISOString();
      const newP: Patient = {
        id: 'pat-' + Date.now(),
        ...data,
        created_at: now,
        updated_at: now,
      };
      patientsState = [newP, ...patientsState];
      setStored('patients', patientsState);
      this.recordAuditEvent('PATIENT_CREATE', 'patient', newP.id, { identifier: newP.personal_identifier });
      return newP;
    }
  }

  async updatePatient(id: string, data: Partial<Patient>): Promise<Patient> {
    try {
      return await this.request<Patient>(`/patients/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(data),
      });
    } catch {
      const idx = patientsState.findIndex(p => p.id === id);
      if (idx === -1) throw new Error('Paciente no encontrado');
      patientsState[idx] = { ...patientsState[idx], ...data, updated_at: new Date().toISOString() };
      setStored('patients', patientsState);
      this.recordAuditEvent('PATIENT_UPDATE', 'patient', id, data);
      return patientsState[idx];
    }
  }

  // --- Professionals ---
  async getProfessionals(): Promise<Professional[]> {
    try {
      return await this.request<Professional[]>('/professionals');
    } catch {
      return INITIAL_PROFESSIONALS;
    }
  }

  // --- Appointments ---
  async getAppointments(filters?: { professional_id?: string; patient_id?: string; status?: string }): Promise<Appointment[]> {
    try {
      const q = new URLSearchParams();
      if (filters?.professional_id) q.set('professional_id', filters.professional_id);
      if (filters?.patient_id) q.set('patient_id', filters.patient_id);
      if (filters?.status) q.set('status', filters.status);
      const res = await this.request<PaginatedResponse<Appointment> | Appointment[]>(`/appointments?${q.toString()}`);
      return Array.isArray(res) ? res : res.items;
    } catch {
      let filtered = [...appointmentsState];
      if (filters?.professional_id) filtered = filtered.filter(a => a.professional_id === filters.professional_id);
      if (filters?.patient_id) filtered = filtered.filter(a => a.patient_id === filters.patient_id);
      if (filters?.status) filtered = filtered.filter(a => a.status === filters.status);

      return filtered.map(app => ({
        ...app,
        patient: patientsState.find(p => p.id === app.patient_id),
        professional: INITIAL_PROFESSIONALS.find(pr => pr.id === app.professional_id)
      }));
    }
  }

  async createAppointment(data: { professional_id: string; patient_id: string; starts_at: string; ends_at: string }): Promise<Appointment> {
    try {
      return await this.request<Appointment>('/appointments', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    } catch {
      // Concurrency/Overlap check
      const newStart = new Date(data.starts_at).getTime();
      const newEnd = new Date(data.ends_at).getTime();

      const conflict = appointmentsState.some(a => {
        if (a.professional_id !== data.professional_id) return false;
        if (a.status === 'cancelled') return false;
        const s = new Date(a.starts_at).getTime();
        const e = new Date(a.ends_at).getTime();
        return (newStart < e && newEnd > s);
      });

      if (conflict) {
        throw new Error('Conflicto de agenda: El profesional ya tiene una cita reservada en este intervalo de tiempo.');
      }

      const now = new Date().toISOString();
      const newApp: Appointment = {
        id: 'app-' + Date.now(),
        professional_id: data.professional_id,
        patient_id: data.patient_id,
        starts_at: data.starts_at,
        ends_at: data.ends_at,
        status: 'reserved',
        version: 1,
        created_at: now,
        updated_at: now,
        patient: patientsState.find(p => p.id === data.patient_id),
        professional: INITIAL_PROFESSIONALS.find(pr => pr.id === data.professional_id)
      };

      appointmentsState = [newApp, ...appointmentsState];
      setStored('appointments', appointmentsState);
      this.recordAuditEvent('APPOINTMENT_CREATE', 'appointment', newApp.id, data);
      return newApp;
    }
  }

  async cancelAppointment(id: string, reason: string): Promise<Appointment> {
    try {
      return await this.request<Appointment>(`/appointments/${id}/cancel`, {
        method: 'POST',
        body: JSON.stringify({ cancellation_reason: reason }),
      });
    } catch {
      const idx = appointmentsState.findIndex(a => a.id === id);
      if (idx === -1) throw new Error('Cita no encontrada');
      appointmentsState[idx] = {
        ...appointmentsState[idx],
        status: 'cancelled',
        cancellation_reason: reason,
        updated_at: new Date().toISOString(),
      };
      setStored('appointments', appointmentsState);
      this.recordAuditEvent('APPOINTMENT_CANCEL', 'appointment', id, { reason });
      return appointmentsState[idx];
    }
  }

  // --- Encounters ---
  async getEncounters(filters?: { patient_id?: string; professional_id?: string }): Promise<Encounter[]> {
    try {
      const q = new URLSearchParams();
      if (filters?.patient_id) q.set('patient_id', filters.patient_id);
      if (filters?.professional_id) q.set('professional_id', filters.professional_id);
      const res = await this.request<PaginatedResponse<Encounter> | Encounter[]>(`/encounters?${q.toString()}`);
      return Array.isArray(res) ? res : res.items;
    } catch {
      let filtered = [...encountersState];
      if (filters?.patient_id) filtered = filtered.filter(e => e.patient_id === filters.patient_id);
      if (filters?.professional_id) filtered = filtered.filter(e => e.professional_id === filters.professional_id);

      return filtered.map(enc => ({
        ...enc,
        patient: patientsState.find(p => p.id === enc.patient_id),
        professional: INITIAL_PROFESSIONALS.find(pr => pr.id === enc.professional_id)
      }));
    }
  }

  async getEncounter(id: string): Promise<Encounter> {
    try {
      return await this.request<Encounter>(`/encounters/${id}`);
    } catch {
      const enc = encountersState.find(e => e.id === id);
      if (!enc) throw new Error('Atención clínica no encontrada');
      return {
        ...enc,
        patient: patientsState.find(p => p.id === enc.patient_id),
        professional: INITIAL_PROFESSIONALS.find(pr => pr.id === enc.professional_id)
      };
    }
  }

  async createEncounter(data: { patient_id: string; professional_id: string; reason: string; notes?: string; appointment_id?: string }): Promise<Encounter> {
    try {
      return await this.request<Encounter>('/encounters', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    } catch {
      const now = new Date().toISOString();
      const newEnc: Encounter = {
        id: 'enc-' + Date.now(),
        patient_id: data.patient_id,
        professional_id: data.professional_id,
        appointment_id: data.appointment_id || null,
        occurred_at: now,
        reason: data.reason,
        notes: data.notes || '',
        status: 'draft',
        created_at: now,
        updated_at: now,
        diagnoses: [],
        treatments: [],
        patient: patientsState.find(p => p.id === data.patient_id),
        professional: INITIAL_PROFESSIONALS.find(pr => pr.id === data.professional_id)
      };
      encountersState = [newEnc, ...encountersState];
      setStored('encounters', encountersState);
      this.recordAuditEvent('ENCOUNTER_CREATE', 'encounter', newEnc.id, { reason: newEnc.reason });
      return newEnc;
    }
  }

  async finalizeEncounter(id: string): Promise<Encounter> {
    try {
      return await this.request<Encounter>(`/encounters/${id}/finalize`, {
        method: 'POST',
      });
    } catch {
      const idx = encountersState.findIndex(e => e.id === id);
      if (idx === -1) throw new Error('Atención no encontrada');
      if (encountersState[idx].status === 'finalized') {
        throw new Error('La atención ya se encuentra finalizada e inmutable');
      }
      encountersState[idx] = {
        ...encountersState[idx],
        status: 'finalized',
        updated_at: new Date().toISOString(),
      };
      setStored('encounters', encountersState);
      this.recordAuditEvent('ENCOUNTER_FINALIZED', 'encounter', id, { finalized: true });
      return encountersState[idx];
    }
  }

  async addDiagnosis(encounterId: string, description: string) {
    try {
      return await this.request(`/encounters/${encounterId}/diagnoses`, {
        method: 'POST',
        body: JSON.stringify({ description }),
      });
    } catch {
      const enc = encountersState.find(e => e.id === encounterId);
      if (!enc) throw new Error('Atención no encontrada');
      if (enc.status === 'finalized') throw new Error('Atención finalizada: no modificable');
      const diag = {
        id: 'diag-' + Date.now(),
        encounter_id: encounterId,
        description,
        diagnosed_at: new Date().toISOString(),
      };
      enc.diagnoses = [...(enc.diagnoses || []), diag];
      setStored('encounters', encountersState);
      return diag;
    }
  }

  async addTreatment(encounterId: string, data: { description: string; instructions?: string; starts_on?: string; ends_on?: string }) {
    try {
      return await this.request(`/encounters/${encounterId}/treatments`, {
        method: 'POST',
        body: JSON.stringify(data),
      });
    } catch {
      const enc = encountersState.find(e => e.id === encounterId);
      if (!enc) throw new Error('Atención no encontrada');
      if (enc.status === 'finalized') throw new Error('Atención finalizada: no modificable');
      const treat = {
        id: 'treat-' + Date.now(),
        encounter_id: encounterId,
        ...data,
      };
      enc.treatments = [...(enc.treatments || []), treat];
      setStored('encounters', encountersState);
      return treat;
    }
  }

  // --- Billing ---
  async getInvoices(status?: string): Promise<Invoice[]> {
    try {
      const q = status ? `?status=${status}` : '';
      const res = await this.request<PaginatedResponse<Invoice> | Invoice[]>(`/invoices${q}`);
      return Array.isArray(res) ? res : res.items;
    } catch {
      let filtered = [...invoicesState];
      if (status) filtered = filtered.filter(i => i.status === status);
      return filtered.map(inv => ({
        ...inv,
        patient: patientsState.find(p => p.id === inv.patient_id)
      }));
    }
  }

  async createInvoice(data: { patient_id: string; amount: number; encounter_id?: string; currency?: string; status?: 'pending' | 'paid' }): Promise<Invoice> {
    try {
      return await this.request<Invoice>('/invoices', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    } catch {
      if (data.amount < 0) throw new Error('El monto de la factura debe ser mayor o igual a 0');
      const newInv: Invoice = {
        id: 'inv-' + Date.now(),
        patient_id: data.patient_id,
        encounter_id: data.encounter_id || null,
        issued_at: new Date().toISOString(),
        amount: data.amount,
        currency: data.currency || 'CLP',
        status: data.status || 'pending',
        patient: patientsState.find(p => p.id === data.patient_id)
      };
      invoicesState = [newInv, ...invoicesState];
      setStored('invoices', invoicesState);
      this.recordAuditEvent('INVOICE_CREATE', 'invoice', newInv.id, { amount: newInv.amount });
      return newInv;
    }
  }

  // --- Reports ---
  async getOperationalReport(): Promise<OperationalReport> {
    try {
      return await this.request<OperationalReport>('/reports/operations');
    } catch {
      return MOCK_OPERATIONS_REPORT;
    }
  }

  async getBillingReport(): Promise<BillingReport> {
    try {
      return await this.request<BillingReport>('/reports/billing');
    } catch {
      return MOCK_BILLING_REPORT;
    }
  }

  // --- Admin ---
  async getUsers(): Promise<User[]> {
    try {
      return await this.request<User[]>('/admin/users');
    } catch {
      return INITIAL_USERS;
    }
  }

  async getAuditEvents(): Promise<AuditEvent[]> {
    try {
      const res = await this.request<PaginatedResponse<AuditEvent> | AuditEvent[]>('/admin/audit-events');
      return Array.isArray(res) ? res : res.items;
    } catch {
      return auditEventsState;
    }
  }

  private recordAuditEvent(action: string, resource_type: string, resource_id: string, metadata: any) {
    const rawUser = localStorage.getItem('currentUser');
    const user = rawUser ? JSON.parse(rawUser) : null;
    const event: AuditEvent = {
      id: 'aud-' + Date.now(),
      actor_user_id: user?.id || null,
      actor_email: user?.email || 'admin@clinica.cl',
      action,
      resource_type,
      resource_id,
      metadata_json: metadata,
      ip_hash: Math.random().toString(16).substring(2, 10),
      created_at: new Date().toISOString()
    };
    auditEventsState = [event, ...auditEventsState];
    setStored('audit', auditEventsState);
  }
}

export const api = new ApiClient();
