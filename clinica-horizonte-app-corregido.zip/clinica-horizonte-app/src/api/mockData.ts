import {
  Patient,
  Professional,
  Appointment,
  Encounter,
  Invoice,
  AuditEvent,
  User,
  OperationalReport,
  BillingReport
} from '../types';

export const INITIAL_USERS: User[] = [
  {
    id: 'u-1',
    email: 'admin@clinica.cl',
    status: 'active',
    role_id: 'r-admin',
    role: { id: 'r-admin', name: 'admin', description: 'Administrador General' },
    created_at: '2026-01-10T08:00:00Z',
    updated_at: '2026-01-10T08:00:00Z',
  },
  {
    id: 'u-2',
    email: 'doctor@clinica.cl',
    status: 'active',
    role_id: 'r-doctor',
    role: { id: 'r-doctor', name: 'doctor', description: 'Médico Tratante' },
    created_at: '2026-01-10T08:00:00Z',
    updated_at: '2026-01-10T08:00:00Z',
  },
  {
    id: 'u-3',
    email: 'reception@clinica.cl',
    status: 'active',
    role_id: 'r-receptionist',
    role: { id: 'r-receptionist', name: 'receptionist', description: 'Recepcionista y Agenda' },
    created_at: '2026-01-10T08:00:00Z',
    updated_at: '2026-01-10T08:00:00Z',
  },
  {
    id: 'u-4',
    email: 'billing@clinica.cl',
    status: 'active',
    role_id: 'r-billing',
    role: { id: 'r-billing', name: 'billing', description: 'Facturación y Finanzas' },
    created_at: '2026-01-10T08:00:00Z',
    updated_at: '2026-01-10T08:00:00Z',
  }
];

export const INITIAL_PROFESSIONALS: Professional[] = [
  {
    id: 'p-1',
    user_id: 'u-2',
    specialty: 'Medicina General',
    status: 'active',
    user: { id: 'u-2', email: 'dra.morales@clinica.cl' },
  },
  {
    id: 'p-2',
    user_id: 'u-5',
    specialty: 'Cardiología Adulto',
    status: 'active',
    user: { id: 'u-5', email: 'dr.silva@clinica.cl' },
  },
  {
    id: 'p-3',
    user_id: 'u-6',
    specialty: 'Pediatría y Urgencia',
    status: 'active',
    user: { id: 'u-6', email: 'dr.castro@clinica.cl' },
  },
  {
    id: 'p-4',
    user_id: 'u-7',
    specialty: 'Traumatología y Ortopedia',
    status: 'active',
    user: { id: 'u-7', email: 'dra.herrera@clinica.cl' },
  }
];

export const INITIAL_PATIENTS: Patient[] = [
  {
    id: 'pat-1',
    personal_identifier: '16.782.914-5',
    first_names: 'Valentina Andrea',
    last_names: 'Morales Soto',
    birth_date: '1992-04-14',
    phone: '+56 9 8412 9012',
    email: 'valentina.morales@gmail.com',
    address: 'Av. Providencia 1420, Depto 402, Santiago',
    created_at: '2026-01-15T09:30:00Z',
    updated_at: '2026-02-01T11:00:00Z',
  },
  {
    id: 'pat-2',
    personal_identifier: '12.345.678-9',
    first_names: 'Sebastián Ignacio',
    last_names: 'Araya Fuentes',
    birth_date: '1981-11-23',
    phone: '+56 9 7291 3840',
    email: 's.araya.f@outlook.cl',
    address: 'Calle Los Alerces 850, Las Condes',
    created_at: '2026-01-18T10:15:00Z',
    updated_at: '2026-02-10T14:20:00Z',
  },
  {
    id: 'pat-3',
    personal_identifier: '9.421.830-K',
    first_names: 'Rosa Angélica',
    last_names: 'González Pinto',
    birth_date: '1959-08-30',
    phone: '+56 9 9345 1120',
    email: 'rosa.gonzalez.p@gmail.com',
    address: 'Pasaje El Roble 210, Ñuñoa',
    created_at: '2026-01-20T08:45:00Z',
    updated_at: '2026-02-15T09:10:00Z',
  },
  {
    id: 'pat-4',
    personal_identifier: '18.903.211-3',
    first_names: 'Matías Esteban',
    last_names: 'Valenzuela Castro',
    birth_date: '1998-03-05',
    phone: '+56 9 6554 9912',
    email: 'm.valenzuela98@gmail.com',
    address: 'Av. Vitacura 5400, Vitacura',
    created_at: '2026-02-01T15:20:00Z',
    updated_at: '2026-02-18T16:00:00Z',
  },
  {
    id: 'pat-5',
    personal_identifier: '21.045.192-8',
    first_names: 'Camila Paz',
    last_names: 'Figueroa Muñoz',
    birth_date: '2003-07-19',
    phone: '+56 9 4432 7890',
    email: 'camilapaz.fm@gmail.com',
    address: 'San Martín 432, Santiago Centro',
    created_at: '2026-02-05T12:00:00Z',
    updated_at: '2026-02-20T10:00:00Z',
  }
];

export const INITIAL_APPOINTMENTS: Appointment[] = [
  {
    id: 'app-1',
    professional_id: 'p-1',
    patient_id: 'pat-1',
    starts_at: '2026-10-02T09:00:00Z',
    ends_at: '2026-10-02T09:30:00Z',
    status: 'completed',
    version: 1,
    created_at: '2026-10-01T10:00:00Z',
    updated_at: '2026-10-02T09:30:00Z',
  },
  {
    id: 'app-2',
    professional_id: 'p-2',
    patient_id: 'pat-2',
    starts_at: '2026-10-02T10:00:00Z',
    ends_at: '2026-10-02T10:45:00Z',
    status: 'confirmed',
    version: 1,
    created_at: '2026-10-01T11:30:00Z',
    updated_at: '2026-10-01T11:30:00Z',
  },
  {
    id: 'app-3',
    professional_id: 'p-2',
    patient_id: 'pat-3',
    starts_at: '2026-10-02T11:00:00Z',
    ends_at: '2026-10-02T11:45:00Z',
    status: 'reserved',
    version: 1,
    created_at: '2026-10-01T14:15:00Z',
    updated_at: '2026-10-01T14:15:00Z',
  },
  {
    id: 'app-4',
    professional_id: 'p-4',
    patient_id: 'pat-4',
    starts_at: '2026-10-02T15:00:00Z',
    ends_at: '2026-10-02T15:30:00Z',
    status: 'reserved',
    version: 1,
    created_at: '2026-10-02T08:30:00Z',
    updated_at: '2026-10-02T08:30:00Z',
  },
  {
    id: 'app-5',
    professional_id: 'p-3',
    patient_id: 'pat-5',
    starts_at: '2026-10-03T09:30:00Z',
    ends_at: '2026-10-03T10:00:00Z',
    status: 'confirmed',
    version: 1,
    created_at: '2026-10-01T16:00:00Z',
    updated_at: '2026-10-01T16:00:00Z',
  }
];

export const INITIAL_ENCOUNTERS: Encounter[] = [
  {
    id: 'enc-1',
    appointment_id: 'app-1',
    patient_id: 'pat-1',
    professional_id: 'p-1',
    occurred_at: '2026-10-02T09:05:00Z',
    reason: 'Control rutinario y cefalea tensional recurrente',
    notes: 'Paciente femenina de 34 años acude refiriendo cefaleas holocraneanas vespertinas de 3 semanas de evolución, agravadas por estrés laboral. Al examen físico: PA 120/75 mmHg, FC 68 lpm, afebril. Sin focalidad neurológica ni signos meníngeos. Cuello con contractura paravertebral bilateral marcada.',
    status: 'finalized',
    created_at: '2026-10-02T09:05:00Z',
    updated_at: '2026-10-02T09:30:00Z',
    diagnoses: [
      {
        id: 'diag-1',
        encounter_id: 'enc-1',
        description: 'G44.2 - Cefalea tensional episódica frecuente',
        diagnosed_at: '2026-10-02T09:20:00Z'
      },
      {
        id: 'diag-2',
        encounter_id: 'enc-1',
        description: 'M54.2 - Cervicalgia por contractura muscular',
        diagnosed_at: '2026-10-02T09:22:00Z'
      }
    ],
    treatments: [
      {
        id: 'treat-1',
        encounter_id: 'enc-1',
        description: 'Paracetamol 500 mg + Ciclobenzaprina 5 mg',
        instructions: 'Tomar 1 comprimido nocturno por 5 días en caso de contractura intensa. Evitar conducción nocturna.',
        starts_on: '2026-10-02',
        ends_on: '2026-10-07'
      },
      {
        id: 'treat-2',
        encounter_id: 'enc-1',
        description: 'Derivación a Kinesioterapia cervical',
        instructions: '10 sesiones de reeducación postural y masaje descontracturante.',
        starts_on: '2026-10-05',
        ends_on: '2026-10-25'
      }
    ]
  },
  {
    id: 'enc-2',
    appointment_id: undefined,
    patient_id: 'pat-3',
    professional_id: 'p-2',
    occurred_at: '2026-09-28T11:15:00Z',
    reason: 'Control crónico de Hipertensión Arterial y Dislipidemia',
    notes: 'Paciente de 67 años acude con exámenes de sangre recientes. Glicemia en ayunas: 98 mg/dL, Colesterol Total: 215 mg/dL, LDL: 135 mg/dL, Creatinina: 0.85 mg/dL. PA en consulta: 138/84 mmHg. Buen apego farmacológico a Losartán.',
    status: 'finalized',
    created_at: '2026-09-28T11:15:00Z',
    updated_at: '2026-09-28T11:45:00Z',
    diagnoses: [
      {
        id: 'diag-3',
        encounter_id: 'enc-2',
        description: 'I10 - Hipertensión arterial esencial',
        diagnosed_at: '2026-09-28T11:30:00Z'
      },
      {
        id: 'diag-4',
        encounter_id: 'enc-2',
        description: 'E78.0 - Hipercolesterolemia pura',
        diagnosed_at: '2026-09-28T11:35:00Z'
      }
    ],
    treatments: [
      {
        id: 'treat-3',
        encounter_id: 'enc-2',
        description: 'Losartán potásico 50 mg',
        instructions: 'Tomar 1 comprimido cada mañana en ayunas. Mantener de forma indefinida.',
        starts_on: '2026-09-28',
        ends_on: null
      },
      {
        id: 'treat-4',
        encounter_id: 'enc-2',
        description: 'Atorvastatina 20 mg',
        instructions: 'Tomar 1 comprimido por la noche con la cena.',
        starts_on: '2026-09-28',
        ends_on: '2026-12-28'
      }
    ]
  }
];

export const INITIAL_INVOICES: Invoice[] = [
  {
    id: 'inv-1001',
    patient_id: 'pat-1',
    encounter_id: 'enc-1',
    issued_at: '2026-10-02T09:35:00Z',
    amount: 35000,
    currency: 'CLP',
    status: 'paid',
  },
  {
    id: 'inv-1002',
    patient_id: 'pat-3',
    encounter_id: 'enc-2',
    issued_at: '2026-09-28T11:50:00Z',
    amount: 45000,
    currency: 'CLP',
    status: 'paid',
  },
  {
    id: 'inv-1003',
    patient_id: 'pat-2',
    encounter_id: null,
    issued_at: '2026-10-02T08:15:00Z',
    amount: 48000,
    currency: 'CLP',
    status: 'pending',
  },
  {
    id: 'inv-1004',
    patient_id: 'pat-4',
    encounter_id: null,
    issued_at: '2026-10-01T17:20:00Z',
    amount: 52000,
    currency: 'CLP',
    status: 'pending',
  }
];

export const INITIAL_AUDIT_EVENTS: AuditEvent[] = [
  {
    id: 'aud-1',
    actor_user_id: 'u-1',
    actor_email: 'admin@clinica.cl',
    action: 'USER_LOGIN',
    resource_type: 'auth',
    resource_id: 'u-1',
    metadata_json: { ip: '192.168.1.15', user_agent: 'Mozilla/5.0 Chrome/128' },
    ip_hash: 'a9f243b8c1',
    created_at: '2026-10-02T08:00:15Z'
  },
  {
    id: 'aud-2',
    actor_user_id: 'u-3',
    actor_email: 'reception@clinica.cl',
    action: 'APPOINTMENT_CREATE',
    resource_type: 'appointment',
    resource_id: 'app-4',
    metadata_json: { professional_id: 'p-4', patient_id: 'pat-4', starts_at: '2026-10-02T15:00:00Z' },
    ip_hash: 'b148ce7692',
    created_at: '2026-10-02T08:30:12Z'
  },
  {
    id: 'aud-3',
    actor_user_id: 'u-2',
    actor_email: 'doctor@clinica.cl',
    action: 'ENCOUNTER_FINALIZED',
    resource_type: 'encounter',
    resource_id: 'enc-1',
    metadata_json: { patient_id: 'pat-1', diagnoses_count: 2, treatments_count: 2 },
    ip_hash: 'c3d551ea04',
    created_at: '2026-10-02T09:30:05Z'
  },
  {
    id: 'aud-4',
    actor_user_id: 'u-4',
    actor_email: 'billing@clinica.cl',
    action: 'INVOICE_CREATE',
    resource_type: 'invoice',
    resource_id: 'inv-1001',
    metadata_json: { amount: 35000, currency: 'CLP', status: 'paid' },
    ip_hash: 'd890fa12bc',
    created_at: '2026-10-02T09:35:40Z'
  }
];

export const MOCK_OPERATIONS_REPORT: OperationalReport = {
  period_start: '2026-10-01',
  period_end: '2026-10-31',
  total_appointments: 184,
  completed_appointments: 142,
  cancelled_appointments: 18,
  no_show_appointments: 6,
  total_encounters: 142,
  appointments_by_specialty: {
    'Medicina General': 68,
    'Cardiología Adulto': 42,
    'Pediatría y Urgencia': 46,
    'Traumatología y Ortopedia': 28
  },
  occupancy_rate: 87.5
};

export const MOCK_BILLING_REPORT: BillingReport = {
  period_start: '2026-10-01',
  period_end: '2026-10-31',
  total_billed: 7850000,
  total_paid: 6850000,
  total_pending: 1000000,
  currency: 'CLP',
  invoices_count: 172
};
