export type UserRole =
  | 'admin'
  | 'doctor'
  | 'health_professional'
  | 'receptionist'
  | 'billing'
  | 'support'
  | 'patient';

export interface User {
  id: string;
  email: string;
  status: 'active' | 'inactive' | 'locked';
  role_id: string;
  role?: {
    id: string;
    name: UserRole;
    description: string;
  };
  created_at: string;
  updated_at: string;
}

export interface Patient {
  id: string;
  personal_identifier: string; // RUT chileno (ej: 12.345.678-9)
  first_names: string;
  last_names: string;
  birth_date: string;
  phone?: string | null;
  email?: string | null;
  address?: string | null;
  created_at: string;
  updated_at: string;
}

export interface Professional {
  id: string;
  user_id: string;
  specialty: string;
  status: 'active' | 'inactive';
  user?: {
    id: string;
    email: string;
  };
}

export type AppointmentStatus =
  | 'available'
  | 'reserved'
  | 'confirmed'
  | 'completed'
  | 'cancelled'
  | 'no_show';

export interface Appointment {
  id: string;
  professional_id: string;
  patient_id: string;
  starts_at: string;
  ends_at: string;
  status: AppointmentStatus;
  cancellation_reason?: string | null;
  version: number;
  created_at: string;
  updated_at: string;
  patient?: Patient;
  professional?: Professional;
}

export type EncounterStatus = 'draft' | 'finalized' | 'amended';

export interface Diagnosis {
  id: string;
  encounter_id: string;
  description: string;
  diagnosed_at: string;
}

export interface Treatment {
  id: string;
  encounter_id: string;
  description: string;
  instructions?: string | null;
  starts_on?: string | null;
  ends_on?: string | null;
}

export interface Encounter {
  id: string;
  appointment_id?: string | null;
  patient_id: string;
  professional_id: string;
  occurred_at: string;
  reason: string;
  notes?: string | null;
  status: EncounterStatus;
  created_at: string;
  updated_at: string;
  patient?: Patient;
  professional?: Professional;
  diagnoses?: Diagnosis[];
  treatments?: Treatment[];
}

export type InvoiceStatus = 'pending' | 'paid' | 'cancelled' | 'overdue';

export interface Invoice {
  id: string;
  patient_id: string;
  encounter_id?: string | null;
  issued_at: string;
  amount: number;
  currency: string;
  status: InvoiceStatus;
  patient?: Patient;
}

export interface AuditEvent {
  id: string;
  actor_user_id?: string | null;
  action: string;
  resource_type: string;
  resource_id?: string | null;
  metadata_json?: Record<string, any> | null;
  ip_hash?: string | null;
  created_at: string;
  actor_email?: string | null;
}

export interface OperationalReport {
  period_start: string;
  period_end: string;
  total_appointments: number;
  completed_appointments: number;
  cancelled_appointments: number;
  no_show_appointments: number;
  total_encounters: number;
  appointments_by_specialty: Record<string, number>;
  occupancy_rate: number;
}

export interface BillingReport {
  period_start: string;
  period_end: string;
  total_billed: number;
  total_paid: number;
  total_pending: number;
  currency: string;
  invoices_count: number;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
}
