import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { ProtectedRoute } from './components/ProtectedRoute';

// Feature Pages
import { LoginPage } from './features/auth/LoginPage';
import { DashboardPage } from './features/dashboard/DashboardPage';
import { PatientListPage } from './features/patients/PatientListPage';
import { PatientDetailPage } from './features/patients/PatientDetailPage';
import { AppointmentListPage } from './features/appointments/AppointmentListPage';
import { EncounterListPage } from './features/encounters/EncounterListPage';
import { EncounterDetailPage } from './features/encounters/EncounterDetailPage';
import { BillingListPage } from './features/billing/BillingListPage';
import { ReportsPage } from './features/reports/ReportsPage';
import { UsersPage } from './features/admin/UsersPage';
import { AuditPage } from './features/admin/AuditPage';

export const App: React.FC = () => {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />

      {/* Protected Routes inside Layout */}
      <Route element={<ProtectedRoute />}>
        <Route element={<Layout />}>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/patients" element={<PatientListPage />} />
          <Route path="/patients/:id" element={<PatientDetailPage />} />
          <Route path="/appointments" element={<AppointmentListPage />} />
          <Route path="/encounters" element={<EncounterListPage />} />
          <Route path="/encounters/:id" element={<EncounterDetailPage />} />
          <Route path="/billing" element={<BillingListPage />} />
          <Route path="/reports" element={<ReportsPage />} />

          {/* Admin Restricted */}
          <Route element={<ProtectedRoute allowedRoles={['admin']} />}>
            <Route path="/admin/users" element={<UsersPage />} />
            <Route path="/admin/audit" element={<AuditPage />} />
          </Route>
        </Route>
      </Route>

      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
};

export default App;
