import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { api } from '../api/client';
import { INITIAL_USERS } from '../api/mockData';

interface AuthContextType {
  user: User | null;
  role: UserRole;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  switchDemoUser: (role: UserRole) => void;
  logout: () => Promise<void>;
  hasRole: (allowedRoles: UserRole[]) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const raw = localStorage.getItem('currentUser');
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        // Validar la forma: datos viejos o corruptos no deben romper la app
        if (
          parsed &&
          typeof parsed === 'object' &&
          typeof parsed.email === 'string' &&
          typeof parsed.role?.name === 'string'
        ) {
          return parsed as User;
        }
      } catch {
        /* cae al usuario por defecto */
      }
      localStorage.removeItem('currentUser');
      return INITIAL_USERS[0];
    }
    // Default to admin for seamless immediate exploration
    return INITIAL_USERS[0];
  });

  const [isLoading, setIsLoading] = useState<boolean>(false);

  useEffect(() => {
    if (user) {
      localStorage.setItem('currentUser', JSON.stringify(user));
    } else {
      localStorage.removeItem('currentUser');
    }
  }, [user]);

  const login = async (email: string, pass: string) => {
    setIsLoading(true);
    try {
      const res = await api.login(email, pass);
      setUser(res.user);
    } finally {
      setIsLoading(false);
    }
  };

  const switchDemoUser = (role: UserRole) => {
    const found = INITIAL_USERS.find(u => u.role?.name === role) || {
      id: 'u-' + role,
      email: `${role}@clinica.cl`,
      status: 'active',
      role_id: 'r-' + role,
      role: { id: 'r-' + role, name: role, description: `Rol ${role}` },
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    } as User;

    setUser(found);
  };

  const logout = async () => {
    setIsLoading(true);
    try {
      await api.logout();
    } finally {
      setUser(null);
      setIsLoading(false);
    }
  };

  const currentRole: UserRole = (user?.role?.name as UserRole) || 'doctor';

  const hasRole = (allowedRoles: UserRole[]) => {
    if (!user) return false;
    if (currentRole === 'admin') return true; // Admin has super-access
    return allowedRoles.includes(currentRole);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        role: currentRole,
        isAuthenticated: !!user,
        isLoading,
        login,
        switchDemoUser,
        logout,
        hasRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};
