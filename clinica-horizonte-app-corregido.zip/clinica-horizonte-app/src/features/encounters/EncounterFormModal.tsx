import React, { useState, useEffect } from 'react';
import { Modal, Select, Input, Button, Alert } from '../../components/UI';
import { api } from '../../api/client';
import { Patient, Professional, Encounter } from '../../types';

interface EncounterFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (enc: Encounter) => void;
  initialPatientId?: string;
  initialAppointmentId?: string;
}

export const EncounterFormModal: React.FC<EncounterFormModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  initialPatientId,
  initialAppointmentId,
}) => {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [patientId, setPatientId] = useState(initialPatientId || '');
  const [professionalId, setProfessionalId] = useState('');
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      Promise.all([api.getPatients('', 1, 100), api.getProfessionals()]).then(
        ([pats, profs]) => {
          setPatients(pats.items);
          setProfessionals(profs);
          if (profs.length > 0 && !professionalId) {
            setProfessionalId(profs[0].id);
          }
          if (pats.items.length > 0 && !patientId) {
            setPatientId(initialPatientId || pats.items[0].id);
          }
        }
      );
    }
  }, [isOpen, initialPatientId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const created = await api.createEncounter({
        patient_id: patientId,
        professional_id: professionalId,
        reason: reason.trim(),
        notes: notes.trim(),
        appointment_id: initialAppointmentId,
      });

      onSuccess(created);
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Error al iniciar la atención clínica.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Iniciar Nueva Atención Médica" maxWidth="lg">
      {error && <Alert type="danger" message={error} className="mb-4" />}

      <form onSubmit={handleSubmit} className="space-y-4">
        <Select
          label="Paciente *"
          required
          value={patientId}
          onChange={(e) => setPatientId(e.target.value)}
          options={patients.map((p) => ({
            label: `${p.first_names} ${p.last_names} — RUT: ${p.personal_identifier}`,
            value: p.id,
          }))}
        />

        <Select
          label="Médico Tratante *"
          required
          value={professionalId}
          onChange={(e) => setProfessionalId(e.target.value)}
          options={professionals.map((pr) => ({
            label: `${pr.specialty} (${pr.user?.email || 'Médico'})`,
            value: pr.id,
          }))}
        />

        <Input
          label="Motivo Principal de Consulta *"
          required
          placeholder="Ej: Control cardiovascular / Dolor lumbar agudo"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
        />

        <div>
          <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
            Anamnesis Inicial y Examen Físico
          </label>
          <textarea
            rows={4}
            className="block w-full rounded-lg border border-slate-300 text-sm p-3 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500 placeholder-slate-400"
            placeholder="Signos vitales (PA, FC, Temp), tiempo de evolución, antecedentes..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
        </div>

        <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
          <Button type="button" variant="outline" onClick={onClose} disabled={isLoading}>
            Cancelar
          </Button>
          <Button type="submit" variant="primary" isLoading={isLoading}>
            Abrir Ficha de Atención
          </Button>
        </div>
      </form>
    </Modal>
  );
};
