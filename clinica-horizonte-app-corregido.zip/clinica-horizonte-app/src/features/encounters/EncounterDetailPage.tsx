import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../../api/client';
import { Encounter, Diagnosis, Treatment } from '../../types';
import { Card, Button, Badge, Modal, Input, Alert } from '../../components/UI';
import {
  ArrowLeft,
  Stethoscope,
  Plus,
  Lock,
  CheckCircle2,
  FileCheck,
  User,
  Calendar,
  AlertTriangle,
  Pill,
} from 'lucide-react';

export const EncounterDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [encounter, setEncounter] = useState<Encounter | null>(null);
  const [loading, setLoading] = useState(true);

  // Modals
  const [isDiagModalOpen, setIsDiagModalOpen] = useState(false);
  const [diagDescription, setDiagDescription] = useState('');

  const [isTreatModalOpen, setIsTreatModalOpen] = useState(false);
  const [treatDescription, setTreatDescription] = useState('');
  const [treatInstructions, setTreatInstructions] = useState('');
  const [treatStartsOn, setTreatStartsOn] = useState(new Date().toISOString().split('T')[0]);
  const [treatEndsOn, setTreatEndsOn] = useState('');

  const [isFinalizeModalOpen, setIsFinalizeModalOpen] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchEncounter = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const data = await api.getEncounter(id);
      setEncounter(data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEncounter();
  }, [id]);

  const handleAddDiagnosis = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !diagDescription.trim()) return;
    setIsSubmitting(true);
    setActionError(null);
    try {
      await api.addDiagnosis(id, diagDescription.trim());
      setDiagDescription('');
      setIsDiagModalOpen(false);
      fetchEncounter();
    } catch (err: any) {
      setActionError(err?.message || 'Error al agregar diagnóstico');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAddTreatment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !treatDescription.trim()) return;
    setIsSubmitting(true);
    setActionError(null);
    try {
      await api.addTreatment(id, {
        description: treatDescription.trim(),
        instructions: treatInstructions.trim() || undefined,
        starts_on: treatStartsOn || undefined,
        ends_on: treatEndsOn || undefined,
      });
      setTreatDescription('');
      setTreatInstructions('');
      setTreatEndsOn('');
      setIsTreatModalOpen(false);
      fetchEncounter();
    } catch (err: any) {
      setActionError(err?.message || 'Error al registrar tratamiento');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFinalize = async () => {
    if (!id) return;
    setIsSubmitting(true);
    setActionError(null);
    try {
      await api.finalizeEncounter(id);
      setIsFinalizeModalOpen(false);
      fetchEncounter();
    } catch (err: any) {
      setActionError(err?.message || 'Error al finalizar la atención');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return <div className="py-12 text-center text-slate-500">Cargando ficha de atención...</div>;
  }

  if (!encounter) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-600 mb-4">Atención no encontrada.</p>
        <Link to="/encounters">
          <Button variant="secondary" leftIcon={<ArrowLeft className="w-4 h-4" />}>
            Volver
          </Button>
        </Link>
      </div>
    );
  }

  const isFinalized = encounter.status === 'finalized';

  return (
    <div className="space-y-6">
      {/* Header breadcrumb & actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <Link
            to="/encounters"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors mb-2"
          >
            <ArrowLeft className="w-4 h-4" /> Volver a Atenciones
          </Link>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              Ficha Clínica Electrónica
            </h1>
            <Badge status={encounter.status} />
          </div>
        </div>

        <div>
          {!isFinalized ? (
            <Button
              onClick={() => setIsFinalizeModalOpen(true)}
              variant="success"
              leftIcon={<CheckCircle2 className="w-4 h-4" />}
            >
              Finalizar Atención Médica
            </Button>
          ) : (
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold">
              <Lock className="w-3.5 h-3.5 text-emerald-600" />
              Documento Inmutable y Auditado
            </div>
          )}
        </div>
      </div>

      {actionError && <Alert type="danger" message={actionError} />}

      {/* Patient & Doctor Context Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
            Paciente
          </p>
          <p className="text-base font-bold text-slate-900">
            {encounter.patient
              ? `${encounter.patient.first_names} ${encounter.patient.last_names}`
              : 'Paciente Registrado'}
          </p>
          <p className="text-xs font-mono font-semibold text-brand-700">
            RUT: {encounter.patient?.personal_identifier || 'Sin RUT'}
          </p>
        </div>

        <div>
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
            Médico Tratante
          </p>
          <p className="text-sm font-bold text-slate-800">
            {encounter.professional?.specialty || 'Medicina General'}
          </p>
          <p className="text-xs text-slate-500">
            {encounter.professional?.user?.email || 'doctor@clinica.cl'}
          </p>
        </div>

        <div>
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
            Fecha y Hora de Atención
          </p>
          <p className="text-sm font-medium text-slate-800">
            {new Date(encounter.occurred_at).toLocaleString('es-CL', {
              dateStyle: 'long',
              timeStyle: 'short',
            })}
          </p>
        </div>
      </div>

      {/* Clinical Notes Section (SOAP) */}
      <Card title="Evolución Clínica y Anamnesis">
        <div className="space-y-4">
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">
              Motivo Principal de Consulta
            </h4>
            <p className="text-sm font-semibold text-slate-900 bg-slate-50 p-3 rounded-lg border border-slate-100">
              {encounter.reason}
            </p>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">
              Notas Clínicas, Examen Físico y Hallazgos
            </h4>
            <p className="text-sm text-slate-700 leading-relaxed bg-slate-50 p-4 rounded-lg border border-slate-100 whitespace-pre-line">
              {encounter.notes || 'Sin notas registradas'}
            </p>
          </div>
        </div>
      </Card>

      {/* Diagnoses Section (CIE-10) */}
      <Card
        title="Diagnósticos Clínicos (CIE-10)"
        subtitle="Codificación y registro patológico"
        action={
          !isFinalized && (
            <Button
              size="sm"
              variant="outline"
              leftIcon={<Plus className="w-3.5 h-3.5" />}
              onClick={() => setIsDiagModalOpen(true)}
            >
              Agregar Diagnóstico
            </Button>
          )
        }
      >
        <div className="space-y-2">
          {encounter.diagnoses && encounter.diagnoses.length > 0 ? (
            encounter.diagnoses.map((d) => (
              <div
                key={d.id}
                className="flex items-center justify-between p-3 rounded-xl bg-blue-50/70 border border-blue-100"
              >
                <div className="flex items-center gap-3">
                  <span className="w-2 h-2 rounded-full bg-blue-600" />
                  <span className="text-sm font-semibold text-blue-950">{d.description}</span>
                </div>
                <span className="text-xs text-blue-500 font-mono">
                  {new Date(d.diagnosed_at).toLocaleTimeString('es-CL', {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </span>
              </div>
            ))
          ) : (
            <p className="text-xs text-slate-400 py-3">No hay diagnósticos asociados a esta atención.</p>
          )}
        </div>
      </Card>

      {/* Treatments Section */}
      <Card
        title="Prescripciones y Plan Terapéutico"
        subtitle="Medicamentos, dosis, pauta e indicaciones complementarias"
        action={
          !isFinalized && (
            <Button
              size="sm"
              variant="outline"
              leftIcon={<Plus className="w-3.5 h-3.5" />}
              onClick={() => setIsTreatModalOpen(true)}
            >
              Agregar Receta / Tratamiento
            </Button>
          )
        }
      >
        <div className="space-y-3">
          {encounter.treatments && encounter.treatments.length > 0 ? (
            encounter.treatments.map((t) => (
              <div
                key={t.id}
                className="p-4 rounded-xl bg-emerald-50/60 border border-emerald-100 text-sm space-y-1.5"
              >
                <div className="flex items-center gap-2">
                  <Pill className="w-4 h-4 text-emerald-600" />
                  <h5 className="font-bold text-emerald-950">{t.description}</h5>
                </div>
                {t.instructions && (
                  <p className="text-xs text-emerald-800 bg-white/70 p-2.5 rounded-lg border border-emerald-100">
                    <strong>Pauta / Indicaciones:</strong> {t.instructions}
                  </p>
                )}
                {(t.starts_on || t.ends_on) && (
                  <p className="text-[11px] text-emerald-700">
                    Vigencia: {t.starts_on || 'Inmediato'} hasta {t.ends_on || 'Indefinido'}
                  </p>
                )}
              </div>
            ))
          ) : (
            <p className="text-xs text-slate-400 py-3">No hay tratamientos prescritos en esta atención.</p>
          )}
        </div>
      </Card>

      {/* Add Diagnosis Modal */}
      <Modal
        isOpen={isDiagModalOpen}
        onClose={() => setIsDiagModalOpen(false)}
        title="Incorporar Diagnóstico CIE-10"
        maxWidth="md"
      >
        <form onSubmit={handleAddDiagnosis} className="space-y-4">
          <Input
            label="Descripción del Diagnóstico *"
            required
            placeholder="Ej: I10 - Hipertensión arterial esencial"
            helperText="Formato sugerido: [Código CIE-10] - [Nombre de la patología]"
            value={diagDescription}
            onChange={(e) => setDiagDescription(e.target.value)}
          />

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => setIsDiagModalOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit" variant="primary" isLoading={isSubmitting}>
              Guardar Diagnóstico
            </Button>
          </div>
        </form>
      </Modal>

      {/* Add Treatment Modal */}
      <Modal
        isOpen={isTreatModalOpen}
        onClose={() => setIsTreatModalOpen(false)}
        title="Incorporar Tratamiento / Receta Médica"
        maxWidth="md"
      >
        <form onSubmit={handleAddTreatment} className="space-y-4">
          <Input
            label="Medicamento y Concentración *"
            required
            placeholder="Ej: Losartán potásico 50 mg comprimidos"
            value={treatDescription}
            onChange={(e) => setTreatDescription(e.target.value)}
          />

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Posología e Instrucciones de Uso
            </label>
            <textarea
              rows={2}
              className="block w-full rounded-lg border border-slate-300 text-sm p-2.5 focus:outline-none focus:ring-2 focus:ring-brand-500"
              placeholder="Ej: Tomar 1 comprimido cada 12 horas por 30 días con abundante agua."
              value={treatInstructions}
              onChange={(e) => setTreatInstructions(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Input
              label="Fecha Inicio"
              type="date"
              value={treatStartsOn}
              onChange={(e) => setTreatStartsOn(e.target.value)}
            />
            <Input
              label="Fecha Fin (Opcional)"
              type="date"
              value={treatEndsOn}
              onChange={(e) => setTreatEndsOn(e.target.value)}
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => setIsTreatModalOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit" variant="primary" isLoading={isSubmitting}>
              Guardar Receta
            </Button>
          </div>
        </form>
      </Modal>

      {/* Finalize Confirmation Modal */}
      <Modal
        isOpen={isFinalizeModalOpen}
        onClose={() => setIsFinalizeModalOpen(false)}
        title="Confirmar Finalización de Atención Médica"
        maxWidth="sm"
      >
        <div className="space-y-4">
          <div className="flex items-start gap-3 bg-amber-50 p-3 rounded-xl border border-amber-200 text-amber-800 text-xs">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
            <p>
              <strong>Acción Inreversible:</strong> Al finalizar la atención, la ficha quedará bloqueada en estado <strong>finalized</strong> impidiendo ediciones posteriores según los criterios de trazabilidad clínica HU-03.
            </p>
          </div>

          <p className="text-sm text-slate-600">
            ¿Desea cerrar definitivamente el acto clínico para este paciente?
          </p>

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setIsFinalizeModalOpen(false)}>
              Seguir Editando
            </Button>
            <Button variant="success" onClick={handleFinalize} isLoading={isSubmitting}>
              Sí, Finalizar Atención
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
