import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { api } from '../../api/client';
import { Encounter } from '../../types';
import { Card, Button, Badge } from '../../components/UI';
import { EncounterFormModal } from './EncounterFormModal';
import { Stethoscope, Plus, Eye, Clock, FileText } from 'lucide-react';

export const EncounterListPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const initialPatientId = searchParams.get('patient_id') || undefined;
  const initialAppointmentId = searchParams.get('appointment_id') || undefined;

  const [encounters, setEncounters] = useState<Encounter[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchEncounters = async () => {
    setLoading(true);
    try {
      const data = await api.getEncounters({
        patient_id: initialPatientId,
      });
      setEncounters(data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEncounters();
  }, [initialPatientId]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Atenciones Clínicas y Ficha Médica</h1>
          <p className="text-sm text-slate-500">
            Registro de evoluciones clínicas, diagnósticos CIE-10 y planes terapéuticos
          </p>
        </div>
        <Button
          onClick={() => setIsModalOpen(true)}
          leftIcon={<Plus className="w-4 h-4" />}
          variant="primary"
        >
          Iniciar Atención
        </Button>
      </div>

      {/* Encounters List */}
      <Card noPadding>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-500 border-b border-slate-100">
              <tr>
                <th className="py-3 px-4">Fecha y Hora</th>
                <th className="py-3 px-4">Paciente (RUT)</th>
                <th className="py-3 px-4">Médico Tratante</th>
                <th className="py-3 px-4">Motivo de Consulta</th>
                <th className="py-3 px-4">Estado</th>
                <th className="py-3 px-4 text-right">Detalle</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {encounters.map((enc) => (
                <tr key={enc.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span className="font-semibold text-slate-900 block font-mono">
                      {new Date(enc.occurred_at).toLocaleTimeString('es-CL', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                    <span className="text-xs text-slate-500">
                      {new Date(enc.occurred_at).toLocaleDateString('es-CL', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <p className="font-semibold text-slate-900">
                      {enc.patient ? `${enc.patient.first_names} ${enc.patient.last_names}` : 'Paciente'}
                    </p>
                    <p className="text-xs font-mono text-slate-400">
                      {enc.patient?.personal_identifier}
                    </p>
                  </td>
                  <td className="py-3.5 px-4">
                    <p className="font-medium text-slate-800">
                      {enc.professional?.specialty || 'Medicina General'}
                    </p>
                    <p className="text-xs text-slate-400">
                      {enc.professional?.user?.email || 'doctor@clinica.cl'}
                    </p>
                  </td>
                  <td className="py-3.5 px-4 max-w-sm">
                    <p className="font-medium text-slate-800 truncate">{enc.reason}</p>
                    <div className="flex gap-2 mt-1">
                      {enc.diagnoses && enc.diagnoses.length > 0 && (
                        <span className="text-[10px] bg-sky-50 text-sky-700 px-1.5 py-0.5 rounded border border-sky-200">
                          {enc.diagnoses.length} diagnósticos
                        </span>
                      )}
                      {enc.treatments && enc.treatments.length > 0 && (
                        <span className="text-[10px] bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded border border-emerald-200">
                          {enc.treatments.length} recetas
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <Badge status={enc.status} />
                  </td>
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <Link to={`/encounters/${enc.id}`}>
                      <Button variant="outline" size="sm" leftIcon={<Eye className="w-3.5 h-3.5" />}>
                        {enc.status === 'draft' ? 'Continuar Ficha' : 'Ver Ficha'}
                      </Button>
                    </Link>
                  </td>
                </tr>
              ))}
              {encounters.length === 0 && !loading && (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    No se registran atenciones clínicas.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <EncounterFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        initialPatientId={initialPatientId}
        initialAppointmentId={initialAppointmentId}
        onSuccess={(newEnc) => {
          setEncounters([newEnc, ...encounters]);
        }}
      />
    </div>
  );
};
