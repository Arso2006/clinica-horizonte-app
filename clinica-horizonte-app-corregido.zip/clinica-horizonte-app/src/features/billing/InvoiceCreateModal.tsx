import React, { useState, useEffect } from 'react';
import { Modal, Select, Input, Button, Alert } from '../../components/UI';
import { api } from '../../api/client';
import { Patient, Invoice } from '../../types';

interface InvoiceCreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (inv: Invoice) => void;
}

export const InvoiceCreateModal: React.FC<InvoiceCreateModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [patientId, setPatientId] = useState('');
  const [amount, setAmount] = useState('35000');
  const [status, setStatus] = useState<'pending' | 'paid'>('paid');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      api.getPatients('', 1, 100).then((res) => {
        setPatients(res.items);
        if (res.items.length > 0 && !patientId) {
          setPatientId(res.items[0].id);
        }
      });
    }
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const parsedAmount = parseInt(amount, 10);
    if (isNaN(parsedAmount) || parsedAmount < 0) {
      setError('El monto debe ser un número entero mayor o igual a 0');
      return;
    }

    setIsLoading(true);
    try {
      const created = await api.createInvoice({
        patient_id: patientId,
        amount: parsedAmount,
        currency: 'CLP',
        status,
      });

      onSuccess(created);
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Error al emitir factura');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Emitir Factura / Boleta Clínica" maxWidth="md">
      {error && <Alert type="danger" message={error} className="mb-4" />}

      <form onSubmit={handleSubmit} className="space-y-4">
        <Select
          label="Paciente *"
          required
          value={patientId}
          onChange={(e) => setPatientId(e.target.value)}
          options={patients.map((p) => ({
            label: `${p.first_names} ${p.last_names} — RUT: ${p.personal_identifier}`,
            value: p.id,
          }))}
        />

        <div className="grid grid-cols-2 gap-4">
          <Input
            label="Monto en Pesos Chilenos (CLP) *"
            type="number"
            min="0"
            required
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="35000"
          />

          <Select
            label="Estado Inicial del Cobro"
            value={status}
            onChange={(e) => setStatus(e.target.value as 'pending' | 'paid')}
            options={[
              { label: 'Pagada (Boleta electrónica)', value: 'paid' },
              { label: 'Pendiente de cobro', value: 'pending' },
            ]}
          />
        </div>

        <div className="bg-slate-50 p-3 rounded-lg border border-slate-200/80 text-xs text-slate-500">
          <strong>Regla de integridad:</strong> Validación estricta de monto no negativo (amount &ge; 0) conforme al modelo relacional del dossier.
        </div>

        <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
          <Button type="button" variant="outline" onClick={onClose} disabled={isLoading}>
            Cancelar
          </Button>
          <Button type="submit" variant="primary" isLoading={isLoading}>
            Emitir Documento
          </Button>
        </div>
      </form>
    </Modal>
  );
};
