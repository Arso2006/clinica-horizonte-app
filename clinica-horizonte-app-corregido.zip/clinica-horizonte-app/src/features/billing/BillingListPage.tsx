import React, { useState, useEffect } from 'react';
import { api } from '../../api/client';
import { Invoice } from '../../types';
import { Card, Button, Badge } from '../../components/UI';
import { InvoiceCreateModal } from './InvoiceCreateModal';
import { Receipt, Plus, Filter, CheckCircle2, Clock, AlertCircle } from 'lucide-react';

export const BillingListPage: React.FC = () => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchInvoices = async () => {
    setLoading(true);
    try {
      const data = await api.getInvoices(statusFilter || undefined);
      setInvoices(data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInvoices();
  }, [statusFilter]);

  const formatCLP = (val: number) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      maximumFractionDigits: 0,
    }).format(val);
  };

  const totalBilled = invoices.reduce((acc, i) => acc + i.amount, 0);
  const totalPaid = invoices.filter((i) => i.status === 'paid').reduce((acc, i) => acc + i.amount, 0);
  const totalPending = invoices.filter((i) => i.status === 'pending').reduce((acc, i) => acc + i.amount, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Facturación y Cobranza</h1>
          <p className="text-sm text-slate-500">
            Control de boletas clínicas, estados de pago y liquidaciones
          </p>
        </div>
        <Button
          onClick={() => setIsModalOpen(true)}
          leftIcon={<Plus className="w-4 h-4" />}
          variant="primary"
        >
          Emitir Factura / Boleta
        </Button>
      </div>

      {/* Financial KPI Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Total Facturado
              </p>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">{formatCLP(totalBilled)}</h3>
              <p className="text-xs text-slate-500 mt-0.5">{invoices.length} documentos emitidos</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-brand-50 flex items-center justify-center text-brand-600">
              <Receipt className="w-6 h-6" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Recaudado (Pagadas)
              </p>
              <h3 className="text-2xl font-bold text-emerald-600 mt-1">{formatCLP(totalPaid)}</h3>
              <p className="text-xs text-emerald-700 font-medium mt-0.5 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Cobro efectivo
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600">
              <CheckCircle2 className="w-6 h-6" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Por Cobrar (Pendiente)
              </p>
              <h3 className="text-2xl font-bold text-amber-600 mt-1">{formatCLP(totalPending)}</h3>
              <p className="text-xs text-amber-700 font-medium mt-0.5 flex items-center gap-1">
                <Clock className="w-3 h-3" /> Pendiente de recepción
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center text-amber-600">
              <Clock className="w-6 h-6" />
            </div>
          </div>
        </Card>
      </div>

      {/* Invoices Table */}
      <Card noPadding>
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-xs bg-white border border-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-brand-500 text-slate-700"
            >
              <option value="">Todos los estados</option>
              <option value="paid">Pagadas</option>
              <option value="pending">Pendientes</option>
              <option value="overdue">Vencidas</option>
              <option value="cancelled">Anuladas</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-500 border-b border-slate-100">
              <tr>
                <th className="py-3 px-4">Folio</th>
                <th className="py-3 px-4">Paciente (RUT)</th>
                <th className="py-3 px-4">Fecha de Emisión</th>
                <th className="py-3 px-4">Monto (CLP)</th>
                <th className="py-3 px-4">Estado</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {invoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-900">{inv.id}</td>
                  <td className="py-3.5 px-4">
                    <p className="font-semibold text-slate-900">
                      {inv.patient ? `${inv.patient.first_names} ${inv.patient.last_names}` : 'Paciente'}
                    </p>
                    <p className="text-xs font-mono text-slate-400">
                      {inv.patient?.personal_identifier}
                    </p>
                  </td>
                  <td className="py-3.5 px-4 text-slate-700">
                    {new Date(inv.issued_at).toLocaleString('es-CL', {
                      dateStyle: 'medium',
                      timeStyle: 'short',
                    })}
                  </td>
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                    {formatCLP(inv.amount)}
                  </td>
                  <td className="py-3.5 px-4">
                    <Badge status={inv.status} />
                  </td>
                </tr>
              ))}
              {invoices.length === 0 && !loading && (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-400">
                    No se registran documentos de facturación.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <InvoiceCreateModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSuccess={(newInv) => setInvoices([newInv, ...invoices])}
      />
    </div>
  );
};
