import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { Button, Input, Alert } from '../../components/UI';
import { Activity, ShieldCheck, Stethoscope, Calendar, Receipt } from 'lucide-react';
import { UserRole } from '../../types';

export const LoginPage: React.FC = () => {
  const { login, switchDemoUser } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('admin@clinica.cl');
  const [password, setPassword] = useState('admin1234');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await login(email, password);
      navigate('/dashboard');
    } catch (err: any) {
      setError(err?.message || 'Error al iniciar sesión. Compruebe sus credenciales.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemo = (role: UserRole, demoEmail: string) => {
    switchDemoUser(role);
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-brand-950 to-slate-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-brand-500 to-sky-400 flex items-center justify-center text-white shadow-xl shadow-brand-500/20">
            <Activity className="w-9 h-9 stroke-[2.5]" />
          </div>
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-white tracking-tight">
          Clínica Horizonte
        </h2>
        <p className="mt-2 text-center text-sm text-slate-300">
          Plataforma de Gestión Clínica, Agenda y Ficha Electrónica
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-6 shadow-2xl rounded-2xl sm:px-10 border border-slate-100">
          {error && <Alert type="danger" message={error} className="mb-6" />}

          <form className="space-y-5" onSubmit={handleSubmit}>
            <Input
              label="Correo Institucional"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="usuario@clinica.cl"
            />

            <Input
              label="Contraseña"
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />

            <Button type="submit" className="w-full mt-2" size="lg" isLoading={loading}>
              Iniciar Sesión
            </Button>
          </form>

          {/* Quick Access Simulation */}
          <div className="mt-8 pt-6 border-t border-slate-200">
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3 text-center">
              Acceso Rápido por Rol (Simulación Demo)
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemo('admin', 'admin@clinica.cl')}
                className="flex items-center gap-2 p-2.5 rounded-lg border border-slate-200 hover:border-brand-500 hover:bg-brand-50/50 text-left transition-all"
              >
                <ShieldCheck className="w-4 h-4 text-brand-600 shrink-0" />
                <div>
                  <p className="text-xs font-bold text-slate-800">Administrador</p>
                  <p className="text-[10px] text-slate-500">Gestión total</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemo('doctor', 'doctor@clinica.cl')}
                className="flex items-center gap-2 p-2.5 rounded-lg border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/50 text-left transition-all"
              >
                <Stethoscope className="w-4 h-4 text-emerald-600 shrink-0" />
                <div>
                  <p className="text-xs font-bold text-slate-800">Médico</p>
                  <p className="text-[10px] text-slate-500">Atención y Ficha</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemo('receptionist', 'reception@clinica.cl')}
                className="flex items-center gap-2 p-2.5 rounded-lg border border-slate-200 hover:border-amber-500 hover:bg-amber-50/50 text-left transition-all"
              >
                <Calendar className="w-4 h-4 text-amber-600 shrink-0" />
                <div>
                  <p className="text-xs font-bold text-slate-800">Recepción</p>
                  <p className="text-[10px] text-slate-500">Agenda y Pacientes</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemo('billing', 'billing@clinica.cl')}
                className="flex items-center gap-2 p-2.5 rounded-lg border border-slate-200 hover:border-sky-500 hover:bg-sky-50/50 text-left transition-all"
              >
                <Receipt className="w-4 h-4 text-sky-600 shrink-0" />
                <div>
                  <p className="text-xs font-bold text-slate-800">Facturación</p>
                  <p className="text-[10px] text-slate-500">Cobros y Reportes</p>
                </div>
              </button>
            </div>
          </div>
        </div>

        <p className="mt-4 text-center text-xs text-slate-400">
          Autenticación segura con Argon2 y JWT rotativo • Clínica Horizonte
        </p>
      </div>
    </div>
  );
};
