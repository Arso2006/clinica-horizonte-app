import React, { useState, useEffect } from 'react';
import { api } from '../../api/client';
import { OperationalReport, BillingReport } from '../../types';
import { Card } from '../../components/UI';
import { BarChart3, TrendingUp, Calendar, AlertCircle, CheckCircle, Clock } from 'lucide-react';

export const ReportsPage: React.FC = () => {
  const [ops, setOps] = useState<OperationalReport | null>(null);
  const [bill, setBill] = useState<BillingReport | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.getOperationalReport(), api.getBillingReport()]).then(([o, b]) => {
      setOps(o);
      setBill(b);
      setLoading(false);
    });
  }, []);

  const formatCLP = (val: number) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      maximumFractionDigits: 0,
    }).format(val);
  };

  if (loading) {
    return <div className="py-12 text-center text-slate-500">Cargando métricas y reportes...</div>;
  }

  const totalApps = ops?.total_appointments || 1;
  const completedPct = Math.round(((ops?.completed_appointments || 0) / totalApps) * 100);
  const cancelledPct = Math.round(((ops?.cancelled_appointments || 0) / totalApps) * 100);
  const noShowPct = Math.round(((ops?.no_show_appointments || 0) / totalApps) * 100);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
          Reportes y Analítica Operacional
        </h1>
        <p className="text-sm text-slate-500">
          Métricas consolidadas de atención clínica, ocupación de agenda y rendimiento financiero
        </p>
      </div>

      {/* Main KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <Card>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Total Citas Programadas
          </p>
          <h3 className="text-3xl font-extrabold text-slate-900 mt-1">{ops?.total_appointments}</h3>
          <p className="text-xs text-slate-500 mt-1">Período actual</p>
        </Card>

        <Card>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Tasa de Ocupación
          </p>
          <h3 className="text-3xl font-extrabold text-emerald-600 mt-1">
            {ops?.occupancy_rate}%
          </h3>
          <p className="text-xs text-emerald-700 mt-1">Rendimiento óptimo de boxes</p>
        </Card>

        <Card>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Facturación Total
          </p>
          <h3 className="text-2xl font-extrabold text-slate-900 mt-1">
            {formatCLP(bill?.total_billed || 0)}
          </h3>
          <p className="text-xs text-slate-500 mt-1">{bill?.invoices_count} facturas emitidas</p>
        </Card>

        <Card>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Recaudación Efectiva
          </p>
          <h3 className="text-2xl font-extrabold text-brand-600 mt-1">
            {formatCLP(bill?.total_paid || 0)}
          </h3>
          <p className="text-xs text-brand-700 mt-1">
            {Math.round(((bill?.total_paid || 0) / (bill?.total_billed || 1)) * 100)}% de cobro
          </p>
        </Card>
      </div>

      {/* Specialty Breakdown and Status Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Appointments by Specialty */}
        <Card
          title="Demanda por Especialidad Médica"
          subtitle="Distribución de consultas atendidas en el período"
        >
          <div className="space-y-4">
            {ops?.appointments_by_specialty &&
              Object.entries(ops.appointments_by_specialty).map(([spec, count]) => {
                const pct = Math.round((count / (ops.total_appointments || 1)) * 100);
                return (
                  <div key={spec} className="space-y-1.5">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-slate-800">{spec}</span>
                      <span className="text-slate-500">
                        {count} citas ({pct}%)
                      </span>
                    </div>
                    <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-brand-600 rounded-full transition-all"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
          </div>
        </Card>

        {/* Appointment Status Breakdown */}
        <Card
          title="Comportamiento y Adherencia de Agenda"
          subtitle="Tasa de cumplimiento, cancelaciones y ausentismo (No-Show)"
        >
          <div className="space-y-5">
            {/* Completed */}
            <div>
              <div className="flex items-center justify-between text-xs font-semibold mb-1">
                <span className="flex items-center gap-1.5 text-emerald-800">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-600" /> Atenciones Realizadas
                </span>
                <span className="text-slate-600 font-bold">
                  {ops?.completed_appointments} ({completedPct}%)
                </span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${completedPct}%` }} />
              </div>
            </div>

            {/* Cancelled */}
            <div>
              <div className="flex items-center justify-between text-xs font-semibold mb-1">
                <span className="flex items-center gap-1.5 text-amber-800">
                  <Clock className="w-3.5 h-3.5 text-amber-600" /> Cancelaciones Oportunas
                </span>
                <span className="text-slate-600 font-bold">
                  {ops?.cancelled_appointments} ({cancelledPct}%)
                </span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-amber-500 rounded-full" style={{ width: `${cancelledPct}%` }} />
              </div>
            </div>

            {/* No Show */}
            <div>
              <div className="flex items-center justify-between text-xs font-semibold mb-1">
                <span className="flex items-center gap-1.5 text-rose-800">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-600" /> Inasistencia sin Aviso (No-Show)
                </span>
                <span className="text-slate-600 font-bold">
                  {ops?.no_show_appointments} ({noShowPct}%)
                </span>
              </div>
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-rose-500 rounded-full" style={{ width: `${noShowPct}%` }} />
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};
