import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../api/client';
import { Appointment, OperationalReport, BillingReport } from '../../types';
import { Card, Badge, Button } from '../../components/UI';
import {
  Users,
  Calendar,
  Stethoscope,
  TrendingUp,
  PlusCircle,
  Clock,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
} from 'lucide-react';

export const DashboardPage: React.FC = () => {
  const { user, role } = useAuth();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [opsReport, setOpsReport] = useState<OperationalReport | null>(null);
  const [billReport, setBillReport] = useState<BillingReport | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const [apps, ops, bill] = await Promise.all([
          api.getAppointments(),
          api.getOperationalReport(),
          api.getBillingReport(),
        ]);
        setAppointments(apps);
        setOpsReport(ops);
        setBillReport(bill);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const formatCLP = (val: number) => {
    return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 }).format(val);
  };

  return (
    <div className="space-y-6">
      {/* Top Welcome Banner */}
      <div className="bg-gradient-to-r from-brand-700 via-brand-600 to-sky-600 rounded-2xl p-6 sm:p-8 text-white shadow-lg shadow-brand-500/10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-xs px-3 py-1 rounded-full text-xs font-semibold tracking-wide uppercase mb-3">
              <ShieldCheck className="w-3.5 h-3.5" />
              Sesión activa: {user?.email}
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Panel de Control Clínico
            </h1>
            <p className="text-brand-100 text-sm mt-1 max-w-xl">
              Bienvenido al sistema de Clínica Horizonte. Monitoreo en tiempo real de agenda, pacientes, atenciones médicas y facturación.
            </p>
          </div>

          <div className="flex flex-wrap gap-2.5">
            <Link to="/appointments">
              <Button variant="secondary" size="md" leftIcon={<PlusCircle className="w-4 h-4" />}>
                Nueva Cita
              </Button>
            </Link>
            <Link to="/patients">
              <Button
                variant="outline"
                size="md"
                className="bg-white/10 text-white border-white/30 hover:bg-white/20"
                leftIcon={<Users className="w-4 h-4" />}
              >
                Registrar Paciente
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <Card className="hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Citas Totales (Mes)</p>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">{opsReport?.total_appointments || 184}</h3>
              <p className="text-xs text-emerald-600 font-medium mt-1 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" /> 142 atendidos exitosamente
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-brand-50 flex items-center justify-center text-brand-600">
              <Calendar className="w-6 h-6" />
            </div>
          </div>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Ocupación de Agenda</p>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">{opsReport?.occupancy_rate || 87.5}%</h3>
              <p className="text-xs text-slate-500 mt-1 flex items-center gap-1">
                <Clock className="w-3 h-3" /> Capacidad objetivo: 180 pac/día
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600">
              <TrendingUp className="w-6 h-6" />
            </div>
          </div>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Atenciones Médicas</p>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">{opsReport?.total_encounters || 142}</h3>
              <p className="text-xs text-emerald-600 font-medium mt-1">
                Fichas clínicas con CIE-10
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-purple-50 flex items-center justify-center text-purple-600">
              <Stethoscope className="w-6 h-6" />
            </div>
          </div>
        </Card>

        <Card className="hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Facturación Mensual</p>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">
                {formatCLP(billReport?.total_billed || 7850000)}
              </h3>
              <p className="text-xs text-amber-700 font-medium mt-1">
                Pendiente: {formatCLP(billReport?.total_pending || 1000000)}
              </p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center text-amber-600">
              <span className="text-xl font-bold font-mono">$</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Main Content: Agenda & Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Today's Agenda */}
        <div className="lg:col-span-2">
          <Card
            title="Agenda Médica de la Jornada"
            subtitle="Citas programadas y estado de atención en tiempo real"
            action={
              <Link to="/appointments" className="text-xs font-bold text-brand-600 hover:text-brand-800 flex items-center gap-1">
                Ver agenda completa <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            }
            noPadding
          >
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600">
                <thead className="bg-slate-50/80 text-[11px] font-bold uppercase tracking-wider text-slate-500 border-b border-slate-100">
                  <tr>
                    <th className="py-3 px-4">Hora</th>
                    <th className="py-3 px-4">Paciente (RUT)</th>
                    <th className="py-3 px-4">Especialidad / Médico</th>
                    <th className="py-3 px-4">Estado</th>
                    <th className="py-3 px-4 text-right">Acción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {appointments.slice(0, 5).map((app) => (
                    <tr key={app.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-3 px-4 font-mono font-medium text-slate-900 whitespace-nowrap">
                        {new Date(app.starts_at).toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className="py-3 px-4">
                        <p className="font-semibold text-slate-900">
                          {app.patient ? `${app.patient.first_names} ${app.patient.last_names}` : 'Paciente'}
                        </p>
                        <p className="text-xs text-slate-400 font-mono">
                          {app.patient?.personal_identifier || 'Sin RUT'}
                        </p>
                      </td>
                      <td className="py-3 px-4">
                        <p className="text-slate-800 font-medium">
                          {app.professional?.specialty || 'Medicina General'}
                        </p>
                        <p className="text-xs text-slate-400">
                          {app.professional?.user?.email || 'Dr. Médico'}
                        </p>
                      </td>
                      <td className="py-3 px-4">
                        <Badge status={app.status} />
                      </td>
                      <td className="py-3 px-4 text-right">
                        <Link to={`/encounters`}>
                          <Button variant="ghost" size="sm">
                            Atender
                          </Button>
                        </Link>
                      </td>
                    </tr>
                  ))}
                  {appointments.length === 0 && (
                    <tr>
                      <td colSpan={5} className="py-6 text-center text-slate-400">
                        No hay citas agendadas para hoy
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </div>

        {/* Right 1 Col: Quick Module Access & Operational Alerts */}
        <div className="space-y-6">
          <Card title="Acciones Rápidas" subtitle="Atajos a los flujos clínicos">
            <div className="space-y-2.5">
              <Link
                to="/patients"
                className="flex items-center justify-between p-3 rounded-xl border border-slate-200/80 hover:border-brand-500 hover:bg-brand-50/40 transition-all group"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-brand-100 text-brand-700">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 group-hover:text-brand-700">
                      Búsqueda de Pacientes
                    </h4>
                    <p className="text-xs text-slate-500">Por RUT o Apellido</p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-brand-600 transition-transform group-hover:translate-x-1" />
              </Link>

              <Link
                to="/encounters"
                className="flex items-center justify-between p-3 rounded-xl border border-slate-200/80 hover:border-emerald-500 hover:bg-emerald-50/40 transition-all group"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700">
                    <Stethoscope className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 group-hover:text-emerald-700">
                      Ficha Electrónica
                    </h4>
                    <p className="text-xs text-slate-500">Diagnósticos y Recetas</p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 transition-transform group-hover:translate-x-1" />
              </Link>

              <Link
                to="/billing"
                className="flex items-center justify-between p-3 rounded-xl border border-slate-200/80 hover:border-amber-500 hover:bg-amber-50/40 transition-all group"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-amber-100 text-amber-700">
                    <span className="text-base font-bold font-mono">$</span>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 group-hover:text-amber-700">
                      Facturación y Boletas
                    </h4>
                    <p className="text-xs text-slate-500">Gestión de Cobro</p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-amber-600 transition-transform group-hover:translate-x-1" />
              </Link>
            </div>
          </Card>

          {/* Operational notice */}
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex gap-3">
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="text-xs text-amber-800 space-y-1">
              <p className="font-bold">Aviso de Auditoría y Trazabilidad</p>
              <p>
                Toda consulta de ficha médica, reserva de hora y emisión de factura queda registrada en la bitácora criptográfica inmutable conforme al artículo de seguridad del dossier.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
