import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { api } from '../../api/client';
import { Appointment, Professional } from '../../types';
import { Card, Button, Badge, Modal, Input, Alert } from '../../components/UI';
import { AppointmentBookingModal } from './AppointmentBookingModal';
import {
  Calendar as CalendarIcon,
  Plus,
  XCircle,
  Stethoscope,
  Filter,
  CheckCircle,
} from 'lucide-react';

export const AppointmentListPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const initialPatientId = searchParams.get('patient_id') || undefined;

  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [selectedProfessional, setSelectedProfessional] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('');
  const [loading, setLoading] = useState(true);

  // Modals
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [cancellingApp, setCancellingApp] = useState<Appointment | null>(null);
  const [cancellationReason, setCancellationReason] = useState('');
  const [actionError, setActionError] = useState<string | null>(null);

  const fetchAppointments = async () => {
    setLoading(true);
    try {
      const data = await api.getAppointments({
        professional_id: selectedProfessional || undefined,
        status: selectedStatus || undefined,
      });
      setAppointments(data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    api.getProfessionals().then(setProfessionals);
  }, []);

  useEffect(() => {
    fetchAppointments();
  }, [selectedProfessional, selectedStatus]);

  const handleCancel = async () => {
    if (!cancellingApp) return;
    setActionError(null);
    try {
      await api.cancelAppointment(
        cancellingApp.id,
        cancellationReason.trim() || 'Cancelada por el paciente/administración'
      );
      setCancellingApp(null);
      setCancellationReason('');
      fetchAppointments();
    } catch (err: any) {
      setActionError(err?.message || 'Error al cancelar la cita');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Agenda Médica y Reservas</h1>
          <p className="text-sm text-slate-500">
            Control de horas, disponibilidad médica y estados de citas
          </p>
        </div>
        <Button
          onClick={() => setIsBookingOpen(true)}
          leftIcon={<Plus className="w-4 h-4" />}
          variant="primary"
        >
          Agendar Cita
        </Button>
      </div>

      {/* Filters Bar */}
      <Card noPadding>
        <div className="p-4 border-b border-slate-100 flex flex-wrap items-center gap-4 bg-slate-50/50">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-wider">
            <Filter className="w-3.5 h-3.5" /> Filtros:
          </div>

          <select
            value={selectedProfessional}
            onChange={(e) => setSelectedProfessional(e.target.value)}
            className="text-xs bg-white border border-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-brand-500 text-slate-700"
          >
            <option value="">Todos los profesionales</option>
            {professionals.map((pr) => (
              <option key={pr.id} value={pr.id}>
                {pr.specialty}
              </option>
            ))}
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="text-xs bg-white border border-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-brand-500 text-slate-700"
          >
            <option value="">Todos los estados</option>
            <option value="reserved">Reservada</option>
            <option value="confirmed">Confirmada</option>
            <option value="completed">Completada</option>
            <option value="cancelled">Cancelada</option>
          </select>

          {(selectedProfessional || selectedStatus) && (
            <button
              onClick={() => {
                setSelectedProfessional('');
                setSelectedStatus('');
              }}
              className="text-xs text-brand-600 hover:text-brand-800 font-medium ml-auto"
            >
              Limpiar filtros
            </button>
          )}
        </div>

        {/* Appointments Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-500 border-b border-slate-100">
              <tr>
                <th className="py-3 px-4">Fecha y Hora</th>
                <th className="py-3 px-4">Paciente (RUT)</th>
                <th className="py-3 px-4">Profesional / Especialidad</th>
                <th className="py-3 px-4">Estado</th>
                <th className="py-3 px-4 text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {appointments.map((app) => (
                <tr key={app.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <span className="font-semibold text-slate-900 block font-mono">
                      {new Date(app.starts_at).toLocaleTimeString('es-CL', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                    <span className="text-xs text-slate-500">
                      {new Date(app.starts_at).toLocaleDateString('es-CL', {
                        weekday: 'short',
                        day: 'numeric',
                        month: 'short',
                      })}
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <p className="font-semibold text-slate-900">
                      {app.patient ? `${app.patient.first_names} ${app.patient.last_names}` : 'Paciente'}
                    </p>
                    <p className="text-xs font-mono text-slate-400">
                      {app.patient?.personal_identifier}
                    </p>
                  </td>
                  <td className="py-3.5 px-4">
                    <p className="font-medium text-slate-800">
                      {app.professional?.specialty || 'Medicina General'}
                    </p>
                    <p className="text-xs text-slate-400">
                      {app.professional?.user?.email || 'doctor@clinica.cl'}
                    </p>
                  </td>
                  <td className="py-3.5 px-4">
                    <Badge status={app.status} />
                    {app.cancellation_reason && (
                      <p className="text-[11px] text-rose-600 mt-0.5">
                        Motivo: {app.cancellation_reason}
                      </p>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-1.5">
                      {app.status !== 'cancelled' && app.status !== 'completed' && (
                        <>
                          <Link to={`/encounters?patient_id=${app.patient_id}&appointment_id=${app.id}`}>
                            <Button variant="outline" size="sm" leftIcon={<Stethoscope className="w-3.5 h-3.5" />}>
                              Atender
                            </Button>
                          </Link>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-rose-600 hover:text-rose-700 hover:bg-rose-50"
                            onClick={() => setCancellingApp(app)}
                            leftIcon={<XCircle className="w-3.5 h-3.5" />}
                          >
                            Cancelar
                          </Button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {appointments.length === 0 && !loading && (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-400">
                    No se registran citas con los filtros seleccionados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Booking Modal */}
      <AppointmentBookingModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
        initialPatientId={initialPatientId}
        onSuccess={() => fetchAppointments()}
      />

      {/* Cancellation Modal */}
      {cancellingApp && (
        <Modal
          isOpen={true}
          onClose={() => setCancellingApp(null)}
          title="Confirmar Cancelación de Cita"
          maxWidth="sm"
        >
          {actionError && <Alert type="danger" message={actionError} className="mb-4" />}
          <div className="space-y-4">
            <p className="text-sm text-slate-600">
              ¿Está seguro de cancelar la cita para el paciente{' '}
              <strong>
                {cancellingApp.patient?.first_names} {cancellingApp.patient?.last_names}
              </strong>?
            </p>
            <Input
              label="Motivo de cancelación"
              placeholder="Ej: Inasistencia avisada / Solicitud del paciente"
              value={cancellationReason}
              onChange={(e) => setCancellationReason(e.target.value)}
            />
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setCancellingApp(null)}>
                Volver
              </Button>
              <Button variant="danger" onClick={handleCancel}>
                Confirmar Cancelación
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
