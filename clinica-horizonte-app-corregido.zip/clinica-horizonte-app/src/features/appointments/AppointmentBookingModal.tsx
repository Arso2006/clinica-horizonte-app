import React, { useState, useEffect } from 'react';
import { Modal, Select, Input, Button, Alert } from '../../components/UI';
import { api } from '../../api/client';
import { Patient, Professional, Appointment } from '../../types';

interface AppointmentBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (app: Appointment) => void;
  initialPatientId?: string;
}

export const AppointmentBookingModal: React.FC<AppointmentBookingModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  initialPatientId,
}) => {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [patientId, setPatientId] = useState(initialPatientId || '');
  const [professionalId, setProfessionalId] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState('10:00');
  const [duration, setDuration] = useState('30');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      Promise.all([api.getPatients('', 1, 100), api.getProfessionals()]).then(
        ([pats, profs]) => {
          setPatients(pats.items);
          setProfessionals(profs);
          if (profs.length > 0 && !professionalId) {
            setProfessionalId(profs[0].id);
          }
          if (pats.items.length > 0 && !patientId) {
            setPatientId(initialPatientId || pats.items[0].id);
          }
        }
      );
    }
  }, [isOpen, initialPatientId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const startsAt = new Date(`${date}T${time}:00`);
      const endsAt = new Date(startsAt.getTime() + parseInt(duration, 10) * 60000);

      const created = await api.createAppointment({
        professional_id: professionalId,
        patient_id: patientId,
        starts_at: startsAt.toISOString(),
        ends_at: endsAt.toISOString(),
      });

      onSuccess(created);
      onClose();
    } catch (err: any) {
      setError(
        err?.message ||
          'Conflicto de agenda: El profesional ya tiene una cita reservada en el bloque seleccionado.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Agendar Nueva Cita Médica" maxWidth="md">
      {error && <Alert type="danger" message={error} className="mb-4" />}

      <form onSubmit={handleSubmit} className="space-y-4">
        <Select
          label="Paciente *"
          required
          value={patientId}
          onChange={(e) => setPatientId(e.target.value)}
          options={patients.map((p) => ({
            label: `${p.first_names} ${p.last_names} — RUT: ${p.personal_identifier}`,
            value: p.id,
          }))}
        />

        <Select
          label="Profesional y Especialidad *"
          required
          value={professionalId}
          onChange={(e) => setProfessionalId(e.target.value)}
          options={professionals.map((pr) => ({
            label: `${pr.specialty} (${pr.user?.email || 'Médico'})`,
            value: pr.id,
          }))}
        />

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <Input
            label="Fecha *"
            type="date"
            required
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />

          <Input
            label="Hora Inicio *"
            type="time"
            required
            value={time}
            onChange={(e) => setTime(e.target.value)}
          />

          <Select
            label="Duración"
            value={duration}
            onChange={(e) => setDuration(e.target.value)}
            options={[
              { label: '30 min', value: '30' },
              { label: '45 min', value: '45' },
              { label: '60 min', value: '60' },
            ]}
          />
        </div>

        <div className="bg-slate-50 p-3 rounded-lg border border-slate-200/80 text-xs text-slate-500">
          <strong>Validación transaccional:</strong> El sistema previene bloqueos duplicados en la agenda del profesional según la regla crítica HU-02 del dossier.
        </div>

        <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
          <Button type="button" variant="outline" onClick={onClose} disabled={isLoading}>
            Cancelar
          </Button>
          <Button type="submit" variant="primary" isLoading={isLoading}>
            Confirmar Reserva
          </Button>
        </div>
      </form>
    </Modal>
  );
};
