import React, { useState, useEffect } from 'react';
import { api } from '../../api/client';
import { AuditEvent } from '../../types';
import { Card, Badge, Modal, Button } from '../../components/UI';
import { ShieldAlert, Eye, Terminal, Clock, UserCheck } from 'lucide-react';

export const AuditPage: React.FC = () => {
  const [events, setEvents] = useState<AuditEvent[]>([]);
  const [selectedEvent, setSelectedEvent] = useState<AuditEvent | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getAuditEvents().then((res) => {
      setEvents(res);
      setLoading(false);
    });
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
          Bitácora de Auditoría y Trazabilidad (Audit Trail)
        </h1>
        <p className="text-sm text-slate-500">
          Registro criptográfico e inmutable de eventos sensibles (accesos, historias clínicas, reservas y cobros)
        </p>
      </div>

      <Card noPadding>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-500 border-b border-slate-100">
              <tr>
                <th className="py-3 px-4">Fecha y Hora</th>
                <th className="py-3 px-4">Actor</th>
                <th className="py-3 px-4">Acción Realizada</th>
                <th className="py-3 px-4">Recurso / Entidad</th>
                <th className="py-3 px-4">Hash IP</th>
                <th className="py-3 px-4 text-right">Metadatos</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {events.map((ev) => (
                <tr key={ev.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4 font-mono text-xs text-slate-700 whitespace-nowrap">
                    {new Date(ev.created_at).toLocaleString('es-CL', {
                      dateStyle: 'short',
                      timeStyle: 'medium',
                    })}
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-slate-900">
                    {ev.actor_email || ev.actor_user_id || 'Sistema'}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-800 border border-slate-200">
                      {ev.action}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-xs text-slate-600">
                    <span className="font-semibold text-slate-800">{ev.resource_type}</span>
                    {ev.resource_id && (
                      <span className="block font-mono text-[11px] text-slate-400">
                        {ev.resource_id}
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 font-mono text-xs text-slate-500">
                    {ev.ip_hash || '127.0.0.1'}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      leftIcon={<Eye className="w-3.5 h-3.5" />}
                      onClick={() => setSelectedEvent(ev)}
                    >
                      Inspeccionar
                    </Button>
                  </td>
                </tr>
              ))}
              {events.length === 0 && !loading && (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    No se registran eventos de auditoría.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Inspect Metadata Modal */}
      {selectedEvent && (
        <Modal
          isOpen={true}
          onClose={() => setSelectedEvent(null)}
          title="Detalle de Evento de Auditoría"
          maxWidth="lg"
        >
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-xl border border-slate-200/80">
              <div>
                <span className="font-semibold text-slate-500 block">Identificador de Evento:</span>
                <span className="font-mono font-bold text-slate-900">{selectedEvent.id}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-500 block">Acción:</span>
                <span className="font-mono font-bold text-brand-700">{selectedEvent.action}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-500 block">Usuario Actor:</span>
                <span className="font-bold text-slate-900">
                  {selectedEvent.actor_email || selectedEvent.actor_user_id || 'Sistema'}
                </span>
              </div>
              <div>
                <span className="font-semibold text-slate-500 block">Timestamp ISO 8601:</span>
                <span className="font-mono text-slate-700">{selectedEvent.created_at}</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
                Cuerpo de Metadatos JSON (Redactado de secretos y contenido sensible)
              </label>
              <pre className="bg-slate-900 text-emerald-400 p-4 rounded-xl text-xs font-mono overflow-x-auto max-h-60">
                {JSON.stringify(selectedEvent.metadata_json || {}, null, 2)}
              </pre>
            </div>

            <div className="flex justify-end pt-2">
              <Button variant="secondary" onClick={() => setSelectedEvent(null)}>
                Cerrar
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
