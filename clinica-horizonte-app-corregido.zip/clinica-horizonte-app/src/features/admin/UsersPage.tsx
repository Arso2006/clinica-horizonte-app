import React, { useState, useEffect } from 'react';
import { api } from '../../api/client';
import { User } from '../../types';
import { Card, Badge } from '../../components/UI';
import { UserCheck, Shield, Mail, Calendar } from 'lucide-react';

export const UsersPage: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getUsers().then((res) => {
      setUsers(res);
      setLoading(false);
    });
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
          Gestión de Usuarios y Control de Acceso (RBAC)
        </h1>
        <p className="text-sm text-slate-500">
          Cuentas institucionales, roles y privilegios de acceso a la plataforma
        </p>
      </div>

      <Card noPadding>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-500 border-b border-slate-100">
              <tr>
                <th className="py-3 px-4">Usuario / Correo</th>
                <th className="py-3 px-4">Rol Asignado</th>
                <th className="py-3 px-4">Estado de Cuenta</th>
                <th className="py-3 px-4">Fecha de Alta</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4 font-semibold text-slate-900 flex items-center gap-2">
                    <Mail className="w-4 h-4 text-slate-400" />
                    <span>{u.email}</span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-brand-50 text-brand-700 border border-brand-200">
                      {u.role?.name || u.role_id}
                    </span>
                    <span className="text-xs text-slate-400 block mt-0.5">
                      {u.role?.description || 'Rol del sistema'}
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <Badge status={u.status} />
                  </td>
                  <td className="py-3.5 px-4 text-xs text-slate-500">
                    {new Date(u.created_at).toLocaleDateString('es-CL', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                    })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};
