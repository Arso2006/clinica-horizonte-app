import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../../api/client';
import { Patient } from '../../types';
import { Card, Button, Input } from '../../components/UI';
import { PatientFormModal } from './PatientFormModal';
import { Search, UserPlus, FileText, Phone, Mail, Eye } from 'lucide-react';

export const PatientListPage: React.FC = () => {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const fetchPatients = async (query = '') => {
    setLoading(true);
    try {
      const res = await api.getPatients(query);
      setPatients(res.items);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPatients(search);
  }, [search]);

  const calculateAge = (birthDate: string) => {
    const diff = Date.now() - new Date(birthDate).getTime();
    const ageDate = new Date(diff);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Directorio de Pacientes</h1>
          <p className="text-sm text-slate-500">
            Registro civil de fichas, antecedentes y contactos de pacientes
          </p>
        </div>
        <Button
          onClick={() => setIsModalOpen(true)}
          leftIcon={<UserPlus className="w-4 h-4" />}
          variant="primary"
        >
          Registrar Paciente
        </Button>
      </div>

      {/* Search and Filters */}
      <Card noPadding>
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <Input
              placeholder="Buscar por RUT, Nombre o Apellido..."
              leftIcon={<Search className="w-4 h-4" />}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        {/* Patients Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-500 border-b border-slate-100">
              <tr>
                <th className="py-3 px-4">RUT / Identificador</th>
                <th className="py-3 px-4">Nombre Completo</th>
                <th className="py-3 px-4">Edad / Nacimiento</th>
                <th className="py-3 px-4">Contacto</th>
                <th className="py-3 px-4">Dirección</th>
                <th className="py-3 px-4 text-right">Ficha Clínica</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {patients.map((pat) => (
                <tr key={pat.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-semibold text-brand-700 whitespace-nowrap">
                    {pat.personal_identifier}
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-slate-900">
                    {pat.first_names} {pat.last_names}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="font-medium text-slate-800">{calculateAge(pat.birth_date)} años</span>
                    <span className="block text-xs text-slate-400">{pat.birth_date}</span>
                  </td>
                  <td className="py-3.5 px-4 space-y-0.5">
                    {pat.phone && (
                      <div className="flex items-center gap-1.5 text-xs text-slate-600">
                        <Phone className="w-3 h-3 text-slate-400" />
                        <span>{pat.phone}</span>
                      </div>
                    )}
                    {pat.email && (
                      <div className="flex items-center gap-1.5 text-xs text-slate-600">
                        <Mail className="w-3 h-3 text-slate-400" />
                        <span>{pat.email}</span>
                      </div>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-xs text-slate-500 max-w-xs truncate">
                    {pat.address || 'Sin dirección registrada'}
                  </td>
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <Link to={`/patients/${pat.id}`}>
                      <Button variant="outline" size="sm" leftIcon={<Eye className="w-3.5 h-3.5" />}>
                        Ver Ficha
                      </Button>
                    </Link>
                  </td>
                </tr>
              ))}
              {patients.length === 0 && !loading && (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    No se encontraron pacientes con los criterios de búsqueda ingresados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      <PatientFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSuccess={(newPat) => setPatients([newPat, ...patients])}
      />
    </div>
  );
};
