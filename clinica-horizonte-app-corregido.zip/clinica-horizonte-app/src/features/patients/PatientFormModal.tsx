import React, { useState } from 'react';
import { Modal, Input, Button, Alert } from '../../components/UI';
import { api } from '../../api/client';
import { Patient } from '../../types';

interface PatientFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (patient: Patient) => void;
}

export const PatientFormModal: React.FC<PatientFormModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [personalIdentifier, setPersonalIdentifier] = useState('');
  const [firstNames, setFirstNames] = useState('');
  const [lastNames, setLastNames] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [phone, setPhone] = useState('+56 9 ');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const created = await api.createPatient({
        personal_identifier: personalIdentifier.trim(),
        first_names: firstNames.trim(),
        last_names: lastNames.trim(),
        birth_date: birthDate,
        phone: phone.trim() || null,
        email: email.trim() || null,
        address: address.trim() || null,
      });

      onSuccess(created);
      onClose();
      // Reset form
      setPersonalIdentifier('');
      setFirstNames('');
      setLastNames('');
      setBirthDate('');
      setPhone('+56 9 ');
      setEmail('');
      setAddress('');
    } catch (err: any) {
      setError(err?.message || 'Error al registrar el paciente.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Registrar Nuevo Paciente" maxWidth="lg">
      {error && <Alert type="danger" message={error} className="mb-4" />}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input
            label="RUT / Identificador Único *"
            required
            placeholder="12.345.678-9"
            helperText="Formato: 12.345.678-K"
            value={personalIdentifier}
            onChange={(e) => setPersonalIdentifier(e.target.value)}
          />
          <Input
            label="Fecha de Nacimiento *"
            type="date"
            required
            value={birthDate}
            onChange={(e) => setBirthDate(e.target.value)}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input
            label="Nombres *"
            required
            placeholder="Ej: Valentina Andrea"
            value={firstNames}
            onChange={(e) => setFirstNames(e.target.value)}
          />
          <Input
            label="Apellidos *"
            required
            placeholder="Ej: Morales Soto"
            value={lastNames}
            onChange={(e) => setLastNames(e.target.value)}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Input
            label="Teléfono de Contacto"
            placeholder="+56 9 1234 5678"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
          <Input
            label="Correo Electrónico"
            type="email"
            placeholder="paciente@correo.cl"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <Input
          label="Dirección de Residencia"
          placeholder="Av. Providencia 1420, Depto 402, Santiago"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
        />

        <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
          <Button type="button" variant="outline" onClick={onClose} disabled={isLoading}>
            Cancelar
          </Button>
          <Button type="submit" variant="primary" isLoading={isLoading}>
            Guardar Paciente
          </Button>
        </div>
      </form>
    </Modal>
  );
};
