import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../../api/client';
import { Patient, Encounter, Appointment, Invoice } from '../../types';
import { Card, Badge, Button } from '../../components/UI';
import {
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Stethoscope,
  Receipt,
  ArrowLeft,
  PlusCircle,
  Clock,
} from 'lucide-react';

export const PatientDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [patient, setPatient] = useState<Patient | null>(null);
  const [encounters, setEncounters] = useState<Encounter[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [activeTab, setActiveTab] = useState<'encounters' | 'appointments' | 'invoices'>('encounters');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    const load = async () => {
      setLoading(true);
      try {
        const [pat, encs, apps, invs] = await Promise.all([
          api.getPatient(id),
          api.getEncounters({ patient_id: id }),
          api.getAppointments({ patient_id: id }),
          api.getInvoices(),
        ]);
        setPatient(pat);
        setEncounters(encs);
        setAppointments(apps);
        setInvoices(invs.filter((i) => i.patient_id === id));
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]);

  if (loading) {
    return (
      <div className="py-12 text-center text-slate-500 font-medium">
        Cargando ficha del paciente...
      </div>
    );
  }

  if (!patient) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-600 mb-4">Paciente no encontrado.</p>
        <Link to="/patients">
          <Button variant="secondary" leftIcon={<ArrowLeft className="w-4 h-4" />}>
            Volver a Pacientes
          </Button>
        </Link>
      </div>
    );
  }

  const formatCLP = (val: number) => {
    return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 }).format(val);
  };

  return (
    <div className="space-y-6">
      {/* Header back button */}
      <div>
        <Link
          to="/patients"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Volver al listado de pacientes
        </Link>
      </div>

      {/* Patient Profile Card */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-brand-600 to-sky-400 text-white flex items-center justify-center font-bold text-xl shadow-md shadow-brand-500/10 shrink-0">
              {patient.first_names[0]}
              {patient.last_names[0]}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-3">
                <h1 className="text-2xl font-extrabold text-slate-900">
                  {patient.first_names} {patient.last_names}
                </h1>
                <span className="px-2.5 py-0.5 rounded-md bg-brand-50 border border-brand-200 text-brand-800 font-mono text-xs font-bold">
                  {patient.personal_identifier}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Fecha de nacimiento: {patient.birth_date} (
                {Math.abs(new Date(Date.now() - new Date(patient.birth_date).getTime()).getUTCFullYear() - 1970)} años)
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Link to={`/appointments?patient_id=${patient.id}`}>
              <Button size="sm" variant="outline" leftIcon={<Calendar className="w-4 h-4" />}>
                Agendar Cita
              </Button>
            </Link>
            <Link to={`/encounters?patient_id=${patient.id}`}>
              <Button size="sm" variant="primary" leftIcon={<Stethoscope className="w-4 h-4" />}>
                Iniciar Atención
              </Button>
            </Link>
          </div>
        </div>

        {/* Contact info bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6 pt-6 border-t border-slate-100 text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <Phone className="w-4 h-4 text-slate-400" />
            <span>{patient.phone || 'Sin teléfono'}</span>
          </div>
          <div className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-slate-400" />
            <span>{patient.email || 'Sin correo'}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-slate-400" />
            <span className="truncate">{patient.address || 'Sin dirección'}</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-slate-200 flex gap-6 text-sm font-semibold">
        <button
          onClick={() => setActiveTab('encounters')}
          className={`pb-3 flex items-center gap-2 transition-all border-b-2 ${
            activeTab === 'encounters'
              ? 'border-brand-600 text-brand-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Stethoscope className="w-4 h-4" />
          Historial de Atenciones ({encounters.length})
        </button>
        <button
          onClick={() => setActiveTab('appointments')}
          className={`pb-3 flex items-center gap-2 transition-all border-b-2 ${
            activeTab === 'appointments'
              ? 'border-brand-600 text-brand-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Calendar className="w-4 h-4" />
          Citas y Agenda ({appointments.length})
        </button>
        <button
          onClick={() => setActiveTab('invoices')}
          className={`pb-3 flex items-center gap-2 transition-all border-b-2 ${
            activeTab === 'invoices'
              ? 'border-brand-600 text-brand-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Receipt className="w-4 h-4" />
          Facturación y Cobros ({invoices.length})
        </button>
      </div>

      {/* Tab Contents */}
      {activeTab === 'encounters' && (
        <div className="space-y-4">
          {encounters.map((enc) => (
            <Card key={enc.id} noPadding>
              <div className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 bg-slate-50/50">
                <div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono font-bold text-slate-500">
                      {new Date(enc.occurred_at).toLocaleDateString('es-CL', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                    <Badge status={enc.status} />
                  </div>
                  <h4 className="text-base font-bold text-slate-900 mt-1">{enc.reason}</h4>
                  <p className="text-xs text-slate-500">
                    Profesional: {enc.professional?.specialty || 'Medicina General'} (
                    {enc.professional?.user?.email || 'doctor@clinica.cl'})
                  </p>
                </div>
                <Link to={`/encounters/${enc.id}`}>
                  <Button variant="outline" size="sm">
                    Ver Registro Completo
                  </Button>
                </Link>
              </div>

              <div className="p-5 space-y-4">
                {enc.notes && (
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
                      Anamnesis y Evolución
                    </p>
                    <p className="text-sm text-slate-700 bg-slate-50 p-3 rounded-lg border border-slate-100">
                      {enc.notes}
                    </p>
                  </div>
                )}

                {/* Diagnoses preview */}
                {enc.diagnoses && enc.diagnoses.length > 0 && (
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                      Diagnósticos Registrados (CIE-10)
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {enc.diagnoses.map((d) => (
                        <span
                          key={d.id}
                          className="px-2.5 py-1 rounded-md bg-blue-50 text-blue-800 border border-blue-200 text-xs font-medium"
                        >
                          {d.description}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Treatments preview */}
                {enc.treatments && enc.treatments.length > 0 && (
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                      Plan Terapéutico / Recetas
                    </p>
                    <div className="space-y-1.5">
                      {enc.treatments.map((t) => (
                        <div key={t.id} className="text-xs p-2.5 rounded-lg bg-emerald-50/60 border border-emerald-100">
                          <p className="font-bold text-emerald-900">{t.description}</p>
                          {t.instructions && <p className="text-emerald-700 mt-0.5">{t.instructions}</p>}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </Card>
          ))}
          {encounters.length === 0 && (
            <Card className="text-center py-8 text-slate-500">
              El paciente no registra atenciones médicas en su ficha histórica.
            </Card>
          )}
        </div>
      )}

      {activeTab === 'appointments' && (
        <Card noPadding>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600">
              <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-500 border-b border-slate-100">
                <tr>
                  <th className="py-3 px-4">Fecha y Hora</th>
                  <th className="py-3 px-4">Profesional</th>
                  <th className="py-3 px-4">Estado</th>
                  <th className="py-3 px-4">Observaciones / Motivo</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {appointments.map((app) => (
                  <tr key={app.id}>
                    <td className="py-3.5 px-4 font-mono font-medium text-slate-900">
                      {new Date(app.starts_at).toLocaleString('es-CL', {
                        dateStyle: 'medium',
                        timeStyle: 'short',
                      })}
                    </td>
                    <td className="py-3.5 px-4 font-medium text-slate-800">
                      {app.professional?.specialty || 'Medicina'}
                    </td>
                    <td className="py-3.5 px-4">
                      <Badge status={app.status} />
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-500">
                      {app.cancellation_reason || 'Sin observaciones'}
                    </td>
                  </tr>
                ))}
                {appointments.length === 0 && (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-slate-400">
                      No hay citas registradas para este paciente.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {activeTab === 'invoices' && (
        <Card noPadding>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600">
              <thead className="bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-500 border-b border-slate-100">
                <tr>
                  <th className="py-3 px-4">Folio Factura</th>
                  <th className="py-3 px-4">Fecha Emisión</th>
                  <th className="py-3 px-4">Monto</th>
                  <th className="py-3 px-4">Estado</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoices.map((inv) => (
                  <tr key={inv.id}>
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900">{inv.id}</td>
                    <td className="py-3.5 px-4 text-slate-700">
                      {new Date(inv.issued_at).toLocaleDateString('es-CL')}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-slate-900 font-mono">
                      {formatCLP(inv.amount)}
                    </td>
                    <td className="py-3.5 px-4">
                      <Badge status={inv.status} />
                    </td>
                  </tr>
                ))}
                {invoices.length === 0 && (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-slate-400">
                      No hay facturas emitidas para este paciente.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
};
