import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Badge } from './UI';
import { LogOut, Activity, UserCheck, Shield } from 'lucide-react';
import { UserRole } from '../types';

export const Navbar: React.FC = () => {
  const { user, role, logout, switchDemoUser } = useAuth();

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
      <div className="px-4 sm:px-6 lg:px-8 flex h-16 items-center justify-between">
        {/* Left: Brand */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-600 to-sky-400 flex items-center justify-center text-white shadow-md shadow-brand-500/20">
            <Activity className="w-6 h-6 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold text-slate-900 tracking-tight">Clínica Horizonte</span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-brand-100 text-brand-700 tracking-wider">
                SGC v1.0
              </span>
            </div>
            <p className="text-xs text-slate-500 hidden sm:block">Plataforma de Gestión Clínica Integral</p>
          </div>
        </div>

        {/* Right: Role Switcher & User Profile */}
        <div className="flex items-center gap-4">
          {/* Quick Demo Role Switcher */}
          <div className="hidden md:flex items-center gap-2 bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs">
            <span className="text-slate-500 px-2 font-medium flex items-center gap-1">
              <UserCheck className="w-3.5 h-3.5" />
              Simular Rol:
            </span>
            {(['admin', 'doctor', 'receptionist', 'billing'] as UserRole[]).map((r) => (
              <button
                key={r}
                onClick={() => switchDemoUser(r)}
                className={`px-2.5 py-1 rounded-md font-medium transition-all ${
                  role === r
                    ? 'bg-white text-brand-700 shadow-xs border border-slate-200/80 font-bold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                {r === 'admin' ? 'Admin' : r === 'doctor' ? 'Médico' : r === 'receptionist' ? 'Recepción' : 'Facturación'}
              </button>
            ))}
          </div>

          {/* User Info */}
          <div className="flex items-center gap-3 pl-2 border-l border-slate-200">
            <div className="text-right hidden sm:block">
              <p className="text-xs font-bold text-slate-800 leading-tight">{user?.email || 'Usuario'}</p>
              <div className="mt-0.5">
                <Badge variant={role === 'admin' ? 'brand' : role === 'doctor' ? 'success' : 'neutral'}>
                  {role.toUpperCase()}
                </Badge>
              </div>
            </div>

            <button
              onClick={() => logout()}
              title="Cerrar sesión"
              className="p-2 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
