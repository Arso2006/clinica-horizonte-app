import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertCircle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught clinical UI error:', error, errorInfo);
  }

  private reset = () => {
    // Limpia sesión y datos locales que pudieran estar corruptos o ser de una versión anterior
    try {
      localStorage.clear();
    } catch {
      /* ignorar */
    }
    window.location.href = '/';
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
          <div className="max-w-md w-full bg-white rounded-2xl p-8 border border-slate-200 shadow-xl text-center">
            <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center">
              <AlertCircle className="w-7 h-7" />
            </div>
            <h2 className="text-xl font-bold text-slate-900 mb-2">Ocurrió un error en la aplicación</h2>
            <p className="text-sm text-slate-500 mb-4">
              Puedes restablecer los datos locales y volver a intentar.
            </p>
            <pre className="text-left text-xs bg-slate-100 text-rose-700 rounded-lg p-3 mb-6 overflow-auto max-h-40 whitespace-pre-wrap">
              {this.state.error?.message || 'Error desconocido'}
            </pre>
            <button
              onClick={this.reset}
              className="inline-flex items-center justify-center gap-2 w-full py-2.5 px-4 bg-brand-600 text-white rounded-xl font-medium hover:bg-brand-700 transition-colors shadow-sm"
            >
              <RefreshCw className="w-4 h-4" />
              Restablecer datos locales
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
