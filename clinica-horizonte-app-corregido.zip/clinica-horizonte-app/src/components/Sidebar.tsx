import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  Users,
  Calendar,
  Stethoscope,
  Receipt,
  BarChart3,
  UserCheck,
  ShieldAlert,
} from 'lucide-react';
import { UserRole } from '../types';

interface NavItem {
  name: string;
  to: string;
  icon: React.ComponentType<{ className?: string }>;
  roles: UserRole[];
}

const navItems: NavItem[] = [
  {
    name: 'Dashboard',
    to: '/dashboard',
    icon: LayoutDashboard,
    roles: ['admin', 'doctor', 'health_professional', 'receptionist', 'billing', 'support', 'patient'],
  },
  {
    name: 'Pacientes',
    to: '/patients',
    icon: Users,
    roles: ['admin', 'doctor', 'health_professional', 'receptionist', 'billing'],
  },
  {
    name: 'Agenda Médica',
    to: '/appointments',
    icon: Calendar,
    roles: ['admin', 'doctor', 'health_professional', 'receptionist'],
  },
  {
    name: 'Atenciones Clínicas',
    to: '/encounters',
    icon: Stethoscope,
    roles: ['admin', 'doctor', 'health_professional'],
  },
  {
    name: 'Facturación',
    to: '/billing',
    icon: Receipt,
    roles: ['admin', 'receptionist', 'billing'],
  },
  {
    name: 'Reportes y Métricas',
    to: '/reports',
    icon: BarChart3,
    roles: ['admin', 'billing', 'receptionist'],
  },
  {
    name: 'Usuarios y Roles',
    to: '/admin/users',
    icon: UserCheck,
    roles: ['admin'],
  },
  {
    name: 'Registro de Auditoría',
    to: '/admin/audit',
    icon: ShieldAlert,
    roles: ['admin'],
  },
];

export const Sidebar: React.FC = () => {
  const { hasRole } = useAuth();

  return (
    <aside className="w-64 bg-white border-r border-slate-200 min-h-[calc(100vh-4rem)] flex flex-col justify-between py-6 px-4">
      <div>
        <p className="px-3 text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
          Módulos Clínicos
        </p>
        <nav className="space-y-1">
          {navItems.map((item) => {
            if (!hasRole(item.roles)) return null;
            const Icon = item.icon;

            return (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-brand-50 text-brand-700 font-semibold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    <Icon
                      className={`w-5 h-5 transition-colors ${
                        isActive ? 'text-brand-600' : 'text-slate-400'
                      }`}
                    />
                    <span>{item.name}</span>
                  </>
                )}
              </NavLink>
            );
          })}
        </nav>
      </div>

      {/* Operational footer badge */}
      <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl text-xs space-y-1">
        <div className="flex items-center gap-1.5 text-slate-700 font-semibold">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          Servicio Operacional
        </div>
        <p className="text-[11px] text-slate-500">
          Clínica Horizonte • Capacidad: ~180 pac/día
        </p>
      </div>
    </aside>
  );
};
